#!/usr/bin/env python3
# bitget.py

import ccxt
import pandas as pd
import numpy as np
import time
from typing import Tuple, Dict, List, Optional, Any, Union

class BitGetexchange:
    def __init__(self, api_key: str, secret_key: str, passphrase: str):
        self.exchange = ccxt.bitget({
            'apiKey': api_key,
            'secret': secret_key,
            'password': passphrase,
            'enableRateLimit': True,
        })
        self.name = "bitget"
    
    def get_ticker(self, market: str) -> Dict:
        """Get current market ticker"""
        ticker = self.exchange.fetch_ticker(market)
        return ticker
    
    def get_orderbook(self, market: str, limit: int = 20) -> Dict:
        """Get current market orderbook"""
        orderbook = self.exchange.fetch_order_book(market, limit)
        return orderbook
    
    def get_account_balances(self) -> pd.DataFrame:
        """Get available account balances"""
        balances = self.exchange.fetch_balance()
        df = pd.DataFrame(columns=['balance', 'available', 'locked'])
        
        for currency, data in balances['total'].items():
            if data > 0:
                df.loc[currency] = {
                    'balance': balances['total'][currency],
                    'available': balances['free'][currency],
                    'locked': balances['used'][currency] if currency in balances['used'] else 0
                }
                
        return df
    
    def get_open_orders(self, market: Optional[str] = None) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Get all open orders
        
        Args:
            market: Optional market to filter by (e.g., 'BTC-USDT')
        
        Returns:
            Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]: All open orders, buy orders, sell orders
        """
        orders = self.exchange.fetch_open_orders(symbol=market)
        
        df = pd.DataFrame(columns=['id', 'market', 'type', 'side', 'price', 'amount', 'filled', 'status'])
        
        for order in orders:
            df.loc[len(df)] = {
                'id': order['id'],
                'market': order['symbol'],
                'type': order['type'],
                'side': order['side'],
                'price': order['price'],
                'amount': order['amount'],
                'filled': order['filled'],
                'status': order['status']
            }
        
        buy_orders = df[df['side'] == 'buy'] if not df.empty else pd.DataFrame()
        sell_orders = df[df['side'] == 'sell'] if not df.empty else pd.DataFrame()
        
        return df, buy_orders, sell_orders
    
    def place_limit_order(self, market: str, side: str, price: float, amount: float) -> Dict:
        """Place a limit order
        
        Args:
            market: Market symbol (e.g., 'BTC-USDT')
            side: 'buy' or 'sell'
            price: Order price
            amount: Order amount
            
        Returns:
            Dict: Order information
        """
        order = self.exchange.create_order(
            symbol=market,
            type='limit',
            side=side,
            amount=amount,
            price=price
        )
        return order
    
    def cancel_order(self, order_id: str, market: str) -> Dict:
        """Cancel a specific order
        
        Args:
            order_id: Order ID to cancel
            market: Market symbol
            
        Returns:
            Dict: Cancellation result
        """
        result = self.exchange.cancel_order(order_id, market)
        return result
    
    def cancel_all_orders(self, market: Optional[str] = None) -> List[Dict]:
        """Cancel all open orders
        
        Args:
            market: Optional market to filter by
            
        Returns:
            List[Dict]: List of cancellation results
        """
        # Get all open orders
        orders, _, _ = self.get_open_orders(market)
        
        results = []
        for _, order in orders.iterrows():
            try:
                result = self.cancel_order(order['id'], order['market'])
                results.append(result)
            except Exception as e:
                print(f"Error cancelling order {order['id']}: {str(e)}")
        
        return results
    
    def get_historical_trades(self, market: str, limit: int = 100) -> pd.DataFrame:
        """Get historical trades for a market
        
        Args:
            market: Market symbol
            limit: Number of trades to fetch
            
        Returns:
            pd.DataFrame: DataFrame of trades
        """
        trades = self.exchange.fetch_trades(market, limit=limit)
        
        df = pd.DataFrame(columns=['id', 'timestamp', 'side', 'price', 'amount'])
        
        for trade in trades:
            df.loc[len(df)] = {
                'id': trade['id'],
                'timestamp': pd.to_datetime(trade['timestamp'], unit='ms'),
                'side': trade['side'],
                'price': trade['price'],
                'amount': trade['amount']
            }
        
        return df