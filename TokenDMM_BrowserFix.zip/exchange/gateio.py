#!/usr/bin/env python3
# gateio.py

import time
import hashlib
import hmac
import requests
import pandas as pd
import json
import gate_api
import logging
import sys
from typing import Tuple, Dict, List, Optional, Any, Union

class GateIo:
    def __init__(self, api_key: str, secret_key: str) -> None:
        self.base_url = "https://api.gateio.ws"
        self.api_key = api_key
        self.api_secret = secret_key
        self.session = requests.session()
        
        # Set up Gate API client
        gate_conf = gate_api.Configuration(key=api_key, secret=secret_key)
        gate_client = gate_api.ApiClient(gate_conf)
        self.spotapi = gate_api.SpotApi(gate_client)
        
        # Logger setup
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        if not self.logger.handlers:
            # Prevent duplicate handlers if initialized multiple times
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)

    def gen_sign(self, method, url, query_string=None, payload_string=None):
        """Generate authentication signature for API requests"""
        t = time.time()
        m = hashlib.sha512()
        m.update((payload_string or "").encode('utf-8'))
        hashed_payload = m.hexdigest()
        s = '%s\n%s\n%s\n%s\n%s' % (method, url, query_string or "", hashed_payload, t)
        sign = hmac.new(self.api_secret.encode('utf-8'), s.encode('utf-8'), hashlib.sha512).hexdigest()
        return {'KEY': self.api_key, 'Timestamp': str(t), 'SIGN': sign}

    def get_funds(self) -> pd.DataFrame:
        """Get available account balances"""
        try:
            funds = self.spotapi.list_spot_accounts()
            funds_dict = []
            for fund in funds:
                funds_dict.append(fund.to_dict())

            funds_df = pd.DataFrame(funds_dict, columns=['currency', 'available', 'locked'])
            funds_df.index = funds_df.currency
            funds_df.available = pd.to_numeric(funds_df.available)
            funds_df.locked = pd.to_numeric(funds_df.locked)
            funds_df['amount'] = funds_df.available + funds_df.locked
            return funds_df
        except Exception as e:
            self.logger.error(f"Error getting funds: {str(e)}")
            # Return empty DataFrame with expected columns
            return pd.DataFrame(columns=['currency', 'available', 'locked', 'amount'])

    def get_ticker(self, market: str) -> Dict:
        """Get current market ticker"""
        try:
            # Convert market format if needed (BTC/USDT to BTC_USDT)
            market = market.replace('/', '_') if '/' in market else market
            ticker = self.spotapi.get_ticker(currency_pair=market)
            return ticker.to_dict()
        except Exception as e:
            self.logger.error(f"Error getting ticker for {market}: {str(e)}")
            return {}

    def get_orderbook(self, market: str, limit: int = 20) -> Dict:
        """Get current market orderbook"""
        try:
            market = market.replace('/', '_') if '/' in market else market
            orderbook = self.spotapi.list_order_book(currency_pair=market, limit=limit)
            return orderbook.to_dict()
        except Exception as e:
            self.logger.error(f"Error getting orderbook for {market}: {str(e)}")
            return {'asks': [], 'bids': []}

    def get_open_orders(self, market: Optional[str] = None) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Get all open orders
        
        Args:
            market: Optional market to filter by (e.g., 'BTC_USDT')
        
        Returns:
            Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]: All open orders, buy orders, sell orders
        """
        try:
            prefix = "/api/v4"
            headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
            url = '/spot/open_orders'
            query_param = f'currency_pair={market}' if market else ''
            
            sign_headers = self.gen_sign('GET', prefix + url, query_param)
            headers.update(sign_headers)
            response = requests.request('GET', self.base_url + prefix + url + (f"?{query_param}" if query_param else ""), headers=headers)
            oo, boo, soo = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
            
            if response.status_code == 200:
                response_json = response.json()
                
                if response_json and len(response_json) > 0 and 'orders' in response_json[0]:
                    orders = response_json[0]['orders']
                    if orders:
                        oo = pd.DataFrame(orders)
                        columns = oo.columns
                        
                        oo['order_id'] = oo['id']
                        oo['price'], oo['amount'], oo['executedQty'] = oo['price'].astype(float), oo['amount'].astype(float), oo['filled_amount'].astype(float)
                        oo['remaining'] = oo['amount'] - oo['executedQty']
                        oo['volume'] = oo['remaining']
                        
                        oo.index = oo.order_id
                        boo = oo[oo["side"] == "buy"]
                        soo = oo[oo["side"] == "sell"]
            
            return oo, boo, soo
        except Exception as e:
            self.logger.error(f"Error getting open orders: {str(e)}")
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    def place_limit_order(self, market: str, side: str, price: float, amount: float, post_only: bool = True) -> Dict:
        """Place a limit order
        
        Args:
            market: Market symbol (e.g., 'BTC_USDT')
            side: 'buy' or 'sell'
            price: Order price
            amount: Order amount
            post_only: Whether to use post-only mode (will only be maker, not taker)
            
        Returns:
            Dict: Order information
        """
        try:
            market = market.replace('/', '_') if '/' in market else market
            client_order_id = f'bot_{int(time.time() * 1000)}_{market}_{side}'
            
            prefix = "/api/v4"
            headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
            url = '/spot/orders'
            query_param = ''
            
            # Create order body
            body_dict = {
                "text": f't-{client_order_id[-10:]}',
                "currency_pair": market,
                "type": "limit",
                "side": side,
                "amount": str(amount),
                "price": str(price),
                "time_in_force": "poc" if post_only else "gtc"
            }
            
            body = json.dumps(body_dict)
            sign_headers = self.gen_sign('POST', prefix + url, query_param, body)
            headers.update(sign_headers)
            response = requests.request('POST', self.base_url + prefix + url, headers=headers, data=body)
            
            if response.status_code != 200 and response.status_code != 201:
                self.logger.error(f"Error placing order: {response.text}")
            
            return response.json()
        except Exception as e:
            self.logger.error(f"Error placing limit order: {str(e)}")
            return {"error": str(e)}

    def cancel_order(self, order_id: str, market: str) -> Dict:
        """Cancel a specific order
        
        Args:
            order_id: Order ID to cancel
            market: Market symbol
            
        Returns:
            Dict: Cancellation result
        """
        try:
            market = market.replace('/', '_') if '/' in market else market
            prefix = "/api/v4"
            headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
            url = f'/spot/orders/{order_id}'
            query_param = f'currency_pair={market}'
            
            sign_headers = self.gen_sign('DELETE', prefix + url, query_param)
            headers.update(sign_headers)
            response = requests.request('DELETE', self.base_url + prefix + url + "?" + query_param, headers=headers)
            
            if response.status_code != 200 and response.status_code != 204:
                self.logger.error(f"Error cancelling order: {response.text}")
                
            return response.json() if response.content else {"success": True}
        except Exception as e:
            self.logger.error(f"Error cancelling order {order_id}: {str(e)}")
            return {"error": str(e)}

    def cancel_all_orders(self, market: Optional[str] = None) -> List[Dict]:
        """Cancel all open orders
        
        Args:
            market: Optional market to filter by
            
        Returns:
            List[Dict]: List of cancellation results
        """
        try:
            # Don't convert market here as it's handled in underlying functions
            if market:
                # Get open orders for the specified market
                oo, _, _ = self.get_open_orders(market)
                results = []
                
                # Cancel each open order
                for _, order in oo.iterrows():
                    result = self.cancel_order(order['id'], market)
                    results.append(result)
                
                return results
            else:
                # Cancel all orders using the bulk endpoint
                prefix = "/api/v4"
                headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
                url = '/spot/orders'
                query_param = ''
                
                sign_headers = self.gen_sign('DELETE', prefix + url, query_param)
                headers.update(sign_headers)
                response = requests.request('DELETE', self.base_url + prefix + url, headers=headers)
                
                if response.status_code != 200:
                    self.logger.error(f"Error cancelling all orders: {response.text}")
                
                return [response.json()] if response.content else [{"success": True}]
        except Exception as e:
            self.logger.error(f"Error cancelling all orders: {str(e)}")
            return [{"error": str(e)}]

    def get_order_book(self, market: str) -> tuple:
        """Get bid, ask and mid prices from the orderbook

        Args:
            market: Market symbol (e.g. 'BTC_USDT')

        Returns:
            tuple: (bid_price, ask_price, mid_price)
        """
        try:
            market = market.replace('/', '_') if '/' in market else market
            prefix = "/api/v4"
            headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
            url = '/spot/order_book'
            query_param = f'currency_pair={market}'
            
            response = requests.request('GET', self.base_url + prefix + url + "?" + query_param, headers=headers)
            
            if response.status_code != 200:
                self.logger.error(f"Error getting orderbook: {response.text}")
                return 0, 0, 0
                
            bid = float(response.json()['bids'][0][0])
            ask = float(response.json()['asks'][0][0])
            return bid, ask, (bid + ask) / 2
        except Exception as e:
            self.logger.error(f"Error getting order book for {market}: {str(e)}")
            return 0, 0, 0

    def get_historical_trades(self, market: str, limit: int = 100) -> pd.DataFrame:
        """Get historical trades for a market
        
        Args:
            market: Market symbol
            limit: Number of trades to fetch
            
        Returns:
            pd.DataFrame: DataFrame of trades
        """
        try:
            market = market.replace('/', '_') if '/' in market else market
            trades = self.spotapi.list_trades(currency_pair=market, limit=limit)
            
            trade_data = []
            for trade in trades:
                trade_dict = trade.to_dict()
                trade_data.append({
                    'id': trade_dict.get('id'),
                    'timestamp': pd.to_datetime(trade_dict.get('create_time_ms'), unit='ms'),
                    'side': trade_dict.get('side'),
                    'price': float(trade_dict.get('price')),
                    'amount': float(trade_dict.get('amount'))
                })
            
            return pd.DataFrame(trade_data)
        except Exception as e:
            self.logger.error(f"Error getting historical trades for {market}: {str(e)}")
            return pd.DataFrame(columns=['id', 'timestamp', 'side', 'price', 'amount'])