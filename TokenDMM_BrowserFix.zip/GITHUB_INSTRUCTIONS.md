# Instructions for Uploading to GitHub

## 1. Export Your Code
The codebase has been packaged into a ZIP file which you can download from the 'Files' section in Replit.

## 2. Create a GitHub Repository
Go to https://github.com/new and create a new repository named "tokendmm".

## 3. Upload to GitHub
After extracting the ZIP file on your local machine, follow these steps:

```bash
# Inside the extracted folder
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/Baconutd/tokendmm.git
git push -u origin main
```

If you encounter permission issues, make sure you have:
1. The correct GitHub username and repository name
2. Proper authentication (using a personal access token or SSH key)
3. Admin permissions for the repository

## Alternative: Manual Upload
If Git commands aren't working, you can also use GitHub's web interface:
1. Go to your repository on GitHub
2. Click "Add file" > "Upload files"
3. Drag and drop the files from the extracted folder
4. Commit the changes

