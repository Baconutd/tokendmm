#!/usr/bin/env python3
import os
import gate_api
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_gateio_api():
    # Get API keys from environment
    api_key = os.environ.get("GATEIO_API_KEY")
    secret_key = os.environ.get("GATEIO_SECRET_KEY")
    
    if not api_key or not secret_key:
        logger.error("API keys not found in environment variables")
        return False
    
    logger.info(f"API Key length: {len(api_key)}")
    logger.info(f"Secret Key length: {len(secret_key)}")
    
    try:
        # Setup API client
        configuration = gate_api.Configuration(
            host = "https://api.gateio.ws/api/v4",
            key = api_key,
            secret = secret_key
        )
        
        api_client = gate_api.ApiClient(configuration)
        spot_api = gate_api.SpotApi(api_client)
        
        # Test API connection by fetching currencies (public endpoint)
        logger.info("Testing public API endpoint...")
        currencies = spot_api.list_currencies()
        
        if not (currencies and len(currencies) > 0):
            logger.warning("API connection success but no currencies returned")
            return False
            
        logger.info(f"Successfully connected to Gate.io API. Found {len(currencies)} currencies.")
        logger.info(f"First few currencies: {[c.currency for c in currencies[:5]]}")
        
        # Test account access (private/authenticated endpoint)
        logger.info("Testing private API endpoint (account balances)...")
        try:
            accounts = spot_api.list_spot_accounts()
            logger.info(f"Successfully retrieved account information. Found {len(accounts)} balances.")
            
            # Log a few balances if any exist
            if accounts and len(accounts) > 0:
                for acc in accounts[:3]:  # Show first 3 balances
                    logger.info(f"Currency: {acc.currency}, Available: {acc.available}, Locked: {acc.locked}")
            
            return True
        except Exception as e:
            logger.error(f"Error accessing account information: {str(e)}")
            return False
            
    except Exception as e:
        logger.error(f"Error connecting to Gate.io API: {str(e)}")
        return False

if __name__ == "__main__":
    success = test_gateio_api()
    print(f"API Test {'Successful' if success else 'Failed'}")