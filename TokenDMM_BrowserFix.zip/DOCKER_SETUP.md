# Docker Setup Guide for Trading Bot Manager

This guide will help you set up and run the Trading Bot Manager application locally using Docker. Running locally will allow you to use your Gate.io API keys with your local IP address, which should already be whitelisted in your Gate.io account.

## Prerequisites

Before you start, make sure you have the following installed on your system:

1. [Docker](https://docs.docker.com/get-docker/)
2. [Docker Compose](https://docs.docker.com/compose/install/)
3. Git (to clone the repository)

## Setup Steps

### 1. Clone the Repository

```bash
git clone <repository-url>
cd trading-bot-manager
```

### 2. Set Up Environment Variables

Create a `.env` file in the root directory of the project by copying the template:

```bash
cp .env.template .env
```

Edit the `.env` file and add your Gate.io API keys:

```
GATEIO_API_KEY=your_gateio_api_key
GATEIO_SECRET_KEY=your_gateio_secret_key
```

### 3. Test API Key Connectivity

Before starting the application, you can test if your API keys are properly set and your IP is whitelisted:

```bash
# Make the script executable
chmod +x test_api_keys.py

# Run the test script with your environment variables
docker build -t api-test -f backend/Dockerfile backend/
docker run --env-file .env api-test python /app/test_api_keys.py
```

If your IP is properly whitelisted, you should see account balance information. If not, you'll get instructions on how to whitelist your current IP.

### 4. Start the Application

Once your API keys are set up, you can start the entire application using Docker Compose:

```bash
docker-compose up --build
```

This command will build and start both the frontend and backend services. The first time you run this, it may take a few minutes to download all dependencies.

### 5. Access the Application

Once everything is running, you can access the application in your browser:

- Frontend: http://localhost:3000
- Backend API: http://localhost:8000

### 6. Creating a Real Trading Bot

To create a real trading bot that uses your Gate.io API (now that you're running locally with your whitelisted IP):

1. Access the frontend at http://localhost:3000
2. Log in with the credentials (username: admin, password: trading123)
3. Click "Add New Bot"
4. Use the following configuration as a template, but modify as needed:

```json
{
    "name": "GateIOBTC",
    "exchange": "gateio",
    "trading_pair": "BTC/USDT",
    "symbol": "BTC",
    "base_symbol": "USDT",
    "quote_interval_seconds": 30,
    "spread_percentage": 0.5,
    "max_order_size": 0.001,
    "reserve_symbol": 0.0001,
    "reserve_base_symbol": 5,
    "strategy": "basic_market_maker",
    "api_keys": {
        "api_key": "use_env_var",
        "secret_key": "use_env_var",
        "passphrase": ""
    },
    "additional_params": {
        "min_order_size": 0.0001,
        "min_profit_percentage": 0.1,
        "use_post_only": true,
        "simulation_mode": false,
        "use_real_trading": true
    }
}
```

**Important:**
- Set `simulation_mode` to `false` and `use_real_trading` to `true` to use real trading
- Start with small `max_order_size` values to minimize risk during testing
- Use `post_only` option to ensure you're only making maker orders

### 7. Stopping the Application

To stop the application, press `Ctrl+C` in the terminal where it's running. To completely remove the containers:

```bash
docker-compose down
```

## Troubleshooting

### API Key Issues

If you encounter issues with the Gate.io API:

1. Check that your API keys are correctly entered in the `.env` file
2. Make sure your current IP address is whitelisted in your Gate.io account
3. Run the test script again to verify connectivity: `docker run --env-file .env api-test python /app/test_api_keys.py`

### Container Issues

If containers fail to start or you encounter other Docker-related issues:

1. Check Docker logs: `docker-compose logs`
2. Try rebuilding the containers: `docker-compose build --no-cache`
3. Ensure ports 3000 and 8000 are not already in use on your system

## Security Considerations

- Never commit the `.env` file with real API keys to version control
- Use small trading amounts when testing with real funds
- Regularly check your bot's performance and logs
- Consider using the simulation mode first before switching to real trading