# Simplified Local Setup Guide

If you're having trouble with Docker, you can use this simplified approach to test your Gate.io API connection and run the Trading Bot Manager.

## 1. Test Your API Keys

First, let's verify your Gate.io API keys and check if your IP is properly whitelisted:

### Prerequisites:
- Python 3.7 or later installed on your computer
- Basic packages: `requests`

### Steps:

1. Make sure you have Python installed. You can check by running:
   ```
   python --version
   ```
   or
   ```
   python3 --version
   ```

2. Install the `requests` package if you don't have it:
   ```
   pip install requests
   ```
   or
   ```
   pip3 install requests
   ```

3. Run the API test script:
   ```
   python local_api_test.py
   ```
   or
   ```
   python3 local_api_test.py
   ```

4. When prompted, enter your Gate.io API key and Secret key.

5. The script will tell you if:
   - It can connect to the public API (which doesn't require authentication)
   - It can connect to the private API (which requires authentication and IP whitelisting)
   - If your IP is properly whitelisted

If the test shows that your IP is not whitelisted, you'll need to:
1. Log in to your Gate.io account
2. Go to API Management
3. Find your API key
4. Add your current IP address to the whitelist
5. Run the test again to confirm

## 2. Manual Setup for Running the Application

If Docker isn't working for you, you can run the components individually:

### Backend Setup:

1. Create a virtual environment:
   ```
   python -m venv venv
   ```

2. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - Mac/Linux: `source venv/bin/activate`

3. Install dependencies:
   ```
   pip install -r backend/requirements.txt
   ```

4. Set environment variables:
   - Windows:
     ```
     set GATEIO_API_KEY=your_api_key
     set GATEIO_SECRET_KEY=your_secret_key
     ```
   - Mac/Linux:
     ```
     export GATEIO_API_KEY=your_api_key
     export GATEIO_SECRET_KEY=your_secret_key
     ```

5. Run the backend:
   ```
   cd backend
   uvicorn main:app --host 0.0.0.0 --port 8000 --reload
   ```

### Frontend Setup:

1. Make sure you have Node.js installed

2. Install dependencies:
   ```
   cd frontend
   npm install
   ```

3. Run the frontend:
   ```
   npm run dev
   ```

4. Access the application at: http://localhost:3000

## 3. Running a Real Trading Bot

Once your application is running and your API keys are confirmed to be working:

1. Access the frontend at http://localhost:3000
2. Log in with the credentials (username: admin, password: trading123)
3. Create a new bot using the "Add New Bot" button
4. Use the GateIOBTC_RealTrading.json configuration as a template
5. Make sure to start with small `max_order_size` values to minimize risk during testing