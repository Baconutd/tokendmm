#!/usr/bin/env python3
# helper_v2.py

import os
import time
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple

class Utils:
    def __init__(self, credentials_path: Optional[str] = None, exchange: Optional[str] = None):
        self.credentials_path = credentials_path if credentials_path is not None else ""
        self.exchange = exchange if exchange is not None else "bot"
        self.logger = logging.getLogger(__name__)
        
        # Set up logging
        # Create logs directory if it doesn't exist
        logs_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "logs"))
        os.makedirs(logs_dir, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(os.path.join(logs_dir, f"{self.exchange}_logs.txt"), mode='a')
            ]
        )
    
    def log_info(self, message: str) -> None:
        """Log an info message"""
        self.logger.info(message)
    
    def log_error(self, message: str) -> None:
        """Log an error message"""
        self.logger.error(message)
    
    def post_positions_to_influx(self, exchange: str, subaccount: str, mid: float, 
                                bid_spread: float, ask_spread: float, symbol: str, 
                                position: float) -> None:
        """
        Simulate posting positions to InfluxDB
        
        In a real implementation, this would send data to an InfluxDB instance
        for monitoring and visualization.
        
        Args:
            exchange: Exchange name
            subaccount: Account identifier
            mid: Mid-price
            bid_spread: Bid spread
            ask_spread: Ask spread
            symbol: Trading pair symbol
            position: Current position size
        """
        # In a real implementation, this would send data to InfluxDB
        # For now, we just log the data
        data = {
            "measurement": "bot_positions",
            "tags": {
                "exchange": exchange,
                "subaccount": subaccount,
                "symbol": symbol
            },
            "fields": {
                "mid": mid,
                "bid_spread": bid_spread,
                "ask_spread": ask_spread,
                "position": position,
                "timestamp": datetime.utcnow().isoformat()
            }
        }
        
        self.logger.info(f"Position update: {json.dumps(data)}")
    
    def calculate_spreads(self, mid_price: float, base_spread: float, 
                         position: float, max_position: float) -> tuple:
        """
        Calculate dynamic bid and ask spreads based on current position
        
        Args:
            mid_price: Current mid-price
            base_spread: Base spread percentage
            position: Current position
            max_position: Maximum allowed position
            
        Returns:
            tuple: (bid_spread, ask_spread)
        """
        # Normalize position between -1 and 1
        norm_position = position / max_position if max_position > 0 else 0
        
        # Adjust spreads based on position
        bid_spread = base_spread * (1 + norm_position)
        ask_spread = base_spread * (1 - norm_position)
        
        return bid_spread, ask_spread
    
    def calculate_order_prices(self, mid_price: float, 
                              bid_spread: float, ask_spread: float) -> tuple:
        """
        Calculate order prices based on mid-price and spreads
        
        Args:
            mid_price: Current mid-price
            bid_spread: Bid spread percentage
            ask_spread: Ask spread percentage
            
        Returns:
            tuple: (bid_price, ask_price)
        """
        bid_price = mid_price * (1 - bid_spread)
        ask_price = mid_price * (1 + ask_spread)
        
        return bid_price, ask_price