import React, { useState } from 'react';
import { deployBot } from '../api/api';

function DeployBotForm({ onSuccess, onCancel }) {
  const [formData, setFormData] = useState({
    name: '',
    exchange: 'bitget',
    trading_pair: 'BTC/USDT',
    symbol: 'BTC',
    base_symbol: 'USDT',
    quote_interval_seconds: 30,
    spread_percentage: 0.2,
    max_order_size: 0.01,
    reserve_symbol: 0.001,
    reserve_base_symbol: 10.0,
    api_keys: {
      api_key: '',
      secret_key: '',
      passphrase: ''
    },
    additional_params: {}
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [additionalParamsText, setAdditionalParamsText] = useState('{}');

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'number' ? parseFloat(value) : value
    });
  };
  
  const handleApiKeyChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      api_keys: {
        ...formData.api_keys,
        [name]: value
      }
    });
  };

  const handleAdditionalParamsChange = (e) => {
    setAdditionalParamsText(e.target.value);
    try {
      const parsed = JSON.parse(e.target.value);
      setFormData({
        ...formData,
        additional_params: parsed
      });
      setError(null);
    } catch (err) {
      // Don't update the state yet, wait for valid JSON
      setError('Invalid JSON in additional parameters');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Reset any previous errors
    setError('');
    
    try {
      setLoading(true);
      await deployBot(formData);
      onSuccess();
    } catch (err) {
      // Extract more specific error message from the API response if available
      let errorMessage = err.message;
      
      // Handle specific error cases
      if (errorMessage.includes('already exists')) {
        errorMessage = `A bot with the name "${formData.name}" already exists. Please use a different name.`;
      }
      
      setError(errorMessage);
      console.error('Error deploying bot:', err);
      
      // Don't close the form when there's an error, let the user fix it
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
          <p>{error}</p>
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-gray-700">Bot Name</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., btc_market_maker"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Exchange</label>
          <select
            name="exchange"
            value={formData.exchange}
            onChange={handleInputChange}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="bitget">Bitget</option>
            <option value="gateio">Gate.io</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Trading Pair</label>
          <input
            type="text"
            name="trading_pair"
            value={formData.trading_pair}
            onChange={handleInputChange}
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="BTC/USDT"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Base Currency Symbol</label>
          <input
            type="text"
            name="symbol"
            value={formData.symbol}
            onChange={handleInputChange}
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="BTC"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Quote Currency Symbol</label>
          <input
            type="text"
            name="base_symbol"
            value={formData.base_symbol}
            onChange={handleInputChange}
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="USDT"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Quote Interval (seconds)</label>
          <input
            type="number"
            name="quote_interval_seconds"
            value={formData.quote_interval_seconds}
            onChange={handleInputChange}
            min="1"
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Spread Percentage</label>
          <input
            type="number"
            name="spread_percentage"
            value={formData.spread_percentage}
            onChange={handleInputChange}
            step="0.01"
            min="0.01"
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Max Order Size</label>
          <input
            type="number"
            name="max_order_size"
            value={formData.max_order_size}
            onChange={handleInputChange}
            step="0.0001"
            min="0.0001"
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Reserve Base Currency</label>
          <input
            type="number"
            name="reserve_symbol"
            value={formData.reserve_symbol}
            onChange={handleInputChange}
            step="0.0001"
            min="0"
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
          <p className="mt-1 text-xs text-gray-500">
            Amount of base currency to reserve (not use for trading)
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Reserve Quote Currency</label>
          <input
            type="number"
            name="reserve_base_symbol"
            value={formData.reserve_base_symbol}
            onChange={handleInputChange}
            step="0.01"
            min="0"
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          />
          <p className="mt-1 text-xs text-gray-500">
            Amount of quote currency to reserve (not use for trading)
          </p>
        </div>
      </div>
      
      <div className="border-t border-gray-200 pt-4 pb-2">
        <h3 className="text-lg font-medium text-gray-700 mb-2">API Keys</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">API Key</label>
            <input
              type="text"
              name="api_key"
              value={formData.api_keys.api_key}
              onChange={handleApiKeyChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700">Secret Key</label>
            <input
              type="password"
              name="secret_key"
              value={formData.api_keys.secret_key}
              onChange={handleApiKeyChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700">Passphrase</label>
            <input
              type="password"
              name="passphrase"
              value={formData.api_keys.passphrase}
              onChange={handleApiKeyChange}
              required
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Additional Parameters (JSON)</label>
        <textarea
          value={additionalParamsText}
          onChange={handleAdditionalParamsChange}
          rows="4"
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
          placeholder='{"param1": "value1", "param2": 123}'
        ></textarea>
        <p className="mt-1 text-sm text-gray-500">
          Enter additional parameters as valid JSON
        </p>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={loading || error}
          className={`px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md ${(loading || error) ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {loading ? (
            <span className="inline-flex items-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Deploying...
            </span>
          ) : 'Deploy Bot'}
        </button>
      </div>
    </form>
  );
}

export default DeployBotForm;
