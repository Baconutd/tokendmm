import React, { useState, useEffect } from 'react';
import BotList from './components/BotList';
import DeployBotForm from './components/DeployBotForm';
import EditBotConfig from './components/EditBotConfig';
import { fetchBots, getBotStatus } from './api/api';

function App() {
  const [bots, setBots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedBot, setSelectedBot] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeployFormOpen, setIsDeployFormOpen] = useState(false);

  // Fetch bots when component mounts
  useEffect(() => {
    const loadBots = async () => {
      try {
        setLoading(true);
        const data = await fetchBots();
        
        // Process the bots data to ensure consistent IDs and timestamps
        const processedBots = data.bots.map(bot => ({
          ...bot,
          id: `bot-${bot.name}`,
          // Map different field names consistently
          last_config_update: bot.last_updated || bot.last_config_update,
        }));
        
        // Update state with stable bot data
        setBots(prevBots => {
          // If we have existing bots, merge the data to keep timestamps
          if (prevBots.length > 0) {
            const existingBots = {};
            prevBots.forEach(bot => {
              existingBots[bot.name] = bot;
            });
            
            return processedBots.map(newBot => {
              const existingBot = existingBots[newBot.name];
              if (existingBot) {
                // Merge data, preferring new data but keeping timestamp info if missing
                return {
                  ...newBot,
                  last_config_update: newBot.last_config_update || existingBot.last_config_update,
                  config_hash: newBot.config_hash || existingBot.config_hash
                };
              }
              return newBot;
            });
          }
          
          // First load, just use processed data
          return processedBots;
        });
        
        setError(null);
      } catch (err) {
        setError(`Failed to load bots: ${err.message}`);
        console.error('Error loading bots:', err);
      } finally {
        setLoading(false);
      }
    };

    loadBots();

    // Set up polling to refresh bot list (less frequently)
    const interval = setInterval(loadBots, 15000);
    return () => clearInterval(interval);
  }, []);

  // Create refs outside of useEffect to maintain them
  const botsRef = React.useRef([]);
  const indexRef = React.useRef(0);
  
  // Separate effect to update botsRef when bots changes
  useEffect(() => {
    botsRef.current = bots;
  }, [bots]);
  
  // Poll for real-time status updates for bots but less frequently
  useEffect(() => {
    
    const pollNextBot = async () => {
      try {
        const currentBots = botsRef.current;
        if (currentBots.length === 0) return;
        
        // Get current index and make sure it's within bounds
        if (indexRef.current >= currentBots.length) {
          indexRef.current = 0;
        }
        
        const currentBot = currentBots[indexRef.current];
        
        // Poll status for the current bot
        if (currentBot) {
          try {
            console.log(`Polling status for bot: ${currentBot.name}`);
            const statusData = await getBotStatus(currentBot.name);
            console.log(`Got status data:`, statusData);
            
            // Use a functional state update to avoid stale state issues
            setBots(prevBots => {
              return prevBots.map(bot => {
                if (bot.name === currentBot.name) {
                  // Return updated bot with stable ID
                  // Format uptime in a human-readable way
                  let uptime_formatted = "0s";
                  if (statusData.uptime_seconds) {
                    const seconds = statusData.uptime_seconds;
                    const days = Math.floor(seconds / 86400);
                    const hours = Math.floor((seconds % 86400) / 3600);
                    const minutes = Math.floor((seconds % 3600) / 60);
                    const remainingSeconds = seconds % 60;
                    
                    const parts = [];
                    if (days > 0) parts.push(`${days}d`);
                    if (hours > 0 || days > 0) parts.push(`${hours}h`);
                    if (minutes > 0 || hours > 0 || days > 0) parts.push(`${minutes}m`);
                    parts.push(`${remainingSeconds}s`);
                    
                    uptime_formatted = parts.join(" ");
                  }
                  
                  return {
                    ...bot,
                    // Use id from statusData or generate one from name
                    id: statusData.id || bot.id || `bot-${bot.name}`,
                    status: statusData.status,
                    uptime: statusData.uptime_seconds || 0,
                    uptime_formatted: uptime_formatted,
                    last_config_update: statusData.last_config_update || bot.last_config_update // Use standardized field
                  };
                }
                // Return other bots unchanged
                return bot;
              });
            });
          } catch (err) {
            console.error(`Error polling status for bot ${currentBot.name}:`, err);
            
            // If bot is not found (404), mark it as stopped
            if (err.response && err.response.status === 404) {
              setBots(prevBots => {
                return prevBots.map(bot => {
                  if (bot.name === currentBot.name) {
                    return {
                      ...bot,
                      status: 'stopped',
                      uptime: 0,
                      uptime_formatted: '0s',
                    };
                  }
                  return bot;
                });
              });
            }
          }
        }
        
        // Move to the next bot for the next polling cycle
        indexRef.current = (indexRef.current + 1) % currentBots.length;
      } catch (err) {
        console.error('Error in polling status:', err);
      }
    };
    
    // Poll immediately and then every 20 seconds (reduced frequency)
    console.log('Setting up status polling interval (20 seconds)');
    pollNextBot(); // Execute immediately
    const statusInterval = setInterval(pollNextBot, 20000);
    
    // Clean up
    return () => {
      clearInterval(statusInterval);
    };
  }, []); // Empty dependency array prevents recreation of the polling interval

  const handleEditBot = (bot) => {
    setSelectedBot(bot);
    setIsEditModalOpen(true);
  };

  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
    setSelectedBot(null);
  };

  const handleDeploySuccess = async () => {
    setIsDeployFormOpen(false);
    // Reload the bot list
    try {
      setLoading(true);
      const data = await fetchBots();
      
      // Preserve timestamp and hash information when refreshing
      setBots(prevBots => {
        // Create a map of existing bots for easy lookup
        const existingBots = {};
        prevBots.forEach(bot => {
          existingBots[bot.name] = bot;
        });
        
        // Map new bots but keep some properties from existing ones
        return data.bots.map(newBot => {
          const existingBot = existingBots[newBot.name];
          if (existingBot) {
            return {
              ...newBot,
              id: existingBot.id || newBot.id || `bot-${newBot.name}`,
              // Try to maintain uptime and formatting information
              uptime: existingBot.uptime || 0,
              uptime_formatted: existingBot.uptime_formatted || '0s',
              last_config_update: existingBot.last_config_update,
              name: newBot.name // Ensure name is set correctly
            };
          }
          return {
            ...newBot,
            id: newBot.id || `bot-${newBot.name}`,
            uptime: 0,
            uptime_formatted: '0s',
            name: newBot.name
          };
        });
      });
    } catch (err) {
      setError(`Failed to refresh bots: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-blue-800 text-white p-4 shadow-md">
        <div className="container mx-auto">
          <h1 className="text-2xl font-bold">Trading Bot Manager</h1>
        </div>
      </nav>

      <main className="container mx-auto py-6 px-4">
        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
            <p>{error}</p>
          </div>
        )}

        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Manage Trading Bots</h2>
          <button
            onClick={() => setIsDeployFormOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
          >
            Deploy New Bot
          </button>
        </div>

        <BotList 
          bots={bots} 
          loading={loading} 
          onEdit={handleEditBot} 
          onBotAction={handleDeploySuccess}
        />

        {isDeployFormOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Deploy New Trading Bot</h3>
                <button 
                  onClick={() => setIsDeployFormOpen(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <DeployBotForm onSuccess={handleDeploySuccess} onCancel={() => setIsDeployFormOpen(false)} />
            </div>
          </div>
        )}

        {isEditModalOpen && selectedBot && (
          <EditBotConfig 
            botName={selectedBot.name} 
            onClose={handleCloseEditModal} 
            onSuccess={handleDeploySuccess}
          />
        )}
      </main>

      <footer className="bg-gray-800 text-white p-4 mt-auto">
        <div className="container mx-auto text-center">
          <p>Trading Bot Manager © {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
