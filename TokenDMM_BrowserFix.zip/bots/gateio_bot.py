# gateio_bot.py

import os
import sys
import time
import json
import signal
import logging
import traceback
from pathlib import Path
from typing import Dict
from datetime import datetime
import argparse

# Add project root to python path to resolve imports
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_root not in sys.path:
    sys.path.append(project_root)

import pandas as pd

from exchange.gateio import GateIo
from helper_v2 import Utils

# Setup logging
# Create logs directory if it doesn't exist
logs_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../logs")
os.makedirs(logs_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.join(logs_dir, "gateio_bot.log"), mode='a')
    ]
)

logger = logging.getLogger(__name__)

class GateioBot:
    def __init__(self, config_path: str):
        self.config_path = Path(config_path)
        self.running = True
        self.util = Utils(exchange='gateio')
        self.last_config_mtime = self.config_path.stat().st_mtime
        self.load_config()
        self.setup_exchange()
        logger.info(f"GateIO Bot initialized with config: {config_path}")

    def load_config(self):
        with open(self.config_path) as f:
            self.config = json.load(f)
        logger.info("Configuration loaded successfully")

    def setup_exchange(self):
        keys = self.config["api_keys"]
        
        # Use environment variables if available, otherwise use config
        api_key = os.environ.get("GATEIO_API_KEY", keys["api_key"])
        secret_key = os.environ.get("GATEIO_SECRET_KEY", keys["secret_key"])
        
        try:
            self.exchange = GateIo(
                api_key,
                secret_key
            )
            logger.info("Exchange API connection established")
        except Exception as e:
            logger.error(f"Failed to setup exchange: {str(e)}")
            raise

    def handle_signal(self, signum, frame):
        logger.info("Shutdown signal received, stopping bot...")
        self.running = False

    def run(self):
        signal.signal(signal.SIGINT, self.handle_signal)
        signal.signal(signal.SIGTERM, self.handle_signal)

        symbol = self.config["symbol"]
        base_symbol = self.config["base_symbol"]
        market = f"{symbol}_{base_symbol}"
        
        logger.info(f"Starting GateIO bot for market: {market}")
        
        while self.running:
            try:
                # Reload config if changed
                current_mtime = self.config_path.stat().st_mtime
                if current_mtime != self.last_config_mtime:
                    logger.info("Config file changed, reloading...")
                    self.load_config()
                    self.setup_exchange()
                    self.last_config_mtime = current_mtime

                # Check if real trading is enabled
                use_real_trading = self.config.get('additional_params', {}).get('use_real_trading', False)
                # Allow simulation mode for testing with real market data but fake orders
                simulation_mode = self.config.get('additional_params', {}).get('simulation_mode', False)
                
                if not use_real_trading and not simulation_mode:
                    logger.warning("Trading is disabled in configuration. Set use_real_trading=true or simulation_mode=true in additional_params to enable.")
                    time.sleep(30)  # Sleep for a while to avoid log spam
                    continue
                    
                if simulation_mode:
                    logger.info("Running in SIMULATION MODE - Using real market data but simulated orders")
                elif use_real_trading:
                    logger.info("Running in REAL TRADING MODE - Using real market data and placing real orders")
                
                # Real market making activities
                logger.info(f"Performing market making on {market}")
                
                # 1. Cancel existing orders
                logger.info("Cancelling existing orders")
                if simulation_mode:
                    logger.info("SIMULATION: Simulating cancel all orders")
                else:
                    try:
                        self.exchange.cancel_all_orders(market)
                    except Exception as e:
                        if "whitelist" in str(e).lower():
                            logger.error(f"IP whitelist error when cancelling orders: {str(e)}. Consider adding this IP to your exchange whitelist or using simulation mode.")
                        else:
                            logger.error(f"Failed to cancel orders: {str(e)}")
                
                # 2. Get market data (order book)
                logger.info("Getting market data and balances")
                bid_price, ask_price, mid_price = self.exchange.get_order_book(market)
                if bid_price == 0 or ask_price == 0:
                    logger.error("Could not get valid order book data")
                    time.sleep(5)
                    continue
                    
                logger.info(f"Current market prices - Bid: {bid_price}, Ask: {ask_price}, Mid: {mid_price}")
                
                # Get balances - real or simulated
                symbol_balance = 0
                base_balance = 0
                
                if simulation_mode:
                    # Use simulated balances in simulation mode
                    sim_symbol_balance = self.config.get('additional_params', {}).get('sim_symbol_balance', 0.05)
                    sim_base_balance = self.config.get('additional_params', {}).get('sim_base_balance', 1000.0)
                    
                    symbol_balance = max(0, sim_symbol_balance - self.config["reserve_symbol"])
                    base_balance = max(0, sim_base_balance - self.config["reserve_base_symbol"])
                    logger.info(f"SIMULATION: Using simulated balances")
                else:
                    # Try to get real balances
                    try:
                        balances = self.exchange.get_funds()
                    
                        # Calculate available balances after reserve
                        if symbol.upper() in balances.index:
                            symbol_balance = max(0, balances.loc[symbol.upper(), 'available'] - self.config["reserve_symbol"])
                        
                        if base_symbol.upper() in balances.index:
                            base_balance = max(0, balances.loc[base_symbol.upper(), 'available'] - self.config["reserve_base_symbol"])
                    except Exception as e:
                        if "whitelist" in str(e).lower():
                            logger.error(f"IP whitelist error: {str(e)}. Consider adding this IP to your exchange whitelist or using simulation mode.")
                        else:
                            logger.error(f"Error getting balances: {str(e)}")
                
                logger.info(f"Available balances: {symbol}: {symbol_balance}, {base_symbol}: {base_balance}")
                
                # 3. Calculate optimal bid/ask prices based on spread
                spread_percentage = self.config['spread_percentage'] / 100
                bid_spread = spread_percentage
                ask_spread = spread_percentage
                
                # Basic position-based spread adjustment
                position = symbol_balance - (base_balance / mid_price)
                max_position = self.config['max_order_size'] * 2  # Just an estimate
                
                # Adjust spreads based on position
                position_ratio = min(max(position / max_position, -1), 1) if max_position > 0 else 0
                bid_spread = spread_percentage * (1 + position_ratio)
                ask_spread = spread_percentage * (1 - position_ratio)
                
                bid_price = mid_price * (1 - bid_spread)
                ask_price = mid_price * (1 + ask_spread)
                
                logger.info(f"Calculated order prices - Bid: {bid_price}, Ask: {ask_price}")
                logger.info(f"Spread: Bid {bid_spread*100:.2f}%, Ask {ask_spread*100:.2f}%")
                
                # 4. Place orders
                bid_size = min(self.config['max_order_size'], base_balance / bid_price)
                ask_size = min(self.config['max_order_size'], symbol_balance)
                
                # Get the minimum order size from additional params or use default
                min_order_size = self.config.get('additional_params', {}).get('min_order_size', 0.001)
                use_post_only = self.config.get('additional_params', {}).get('use_post_only', True)
                
                # Only place orders if we have sufficient balance
                if bid_size >= min_order_size:
                    logger.info(f"Placing buy order: {bid_size} {symbol} @ {bid_price} {base_symbol}")
                    
                    if simulation_mode:
                        # Simulate order placement
                        sim_order_id = f"sim_{int(time.time())}_{hash(str(bid_price) + str(bid_size))}"
                        bid_order = {
                            "id": sim_order_id,
                            "market": market,
                            "side": "buy",
                            "price": bid_price,
                            "amount": bid_size,
                            "filled": 0,
                            "status": "open",
                            "simulated": True
                        }
                        logger.info(f"SIMULATION: Buy order placed: {bid_order}")
                    else:
                        # Real order placement
                        try:
                            bid_order = self.exchange.place_limit_order(market, 'buy', bid_price, bid_size, use_post_only)
                            logger.info(f"Buy order placed: {bid_order}")
                        except Exception as e:
                            if "whitelist" in str(e).lower():
                                logger.error(f"IP whitelist error when placing buy order: {str(e)}. Consider adding this IP to your exchange whitelist or using simulation mode.")
                            else:
                                logger.error(f"Failed to place buy order: {str(e)}")
                else:
                    logger.warning(f"Insufficient balance to place buy order. Required: {min_order_size * bid_price} {base_symbol}, Available: {base_balance} {base_symbol}")
                
                if ask_size >= min_order_size:
                    logger.info(f"Placing sell order: {ask_size} {symbol} @ {ask_price} {base_symbol}")
                    
                    if simulation_mode:
                        # Simulate order placement
                        sim_order_id = f"sim_{int(time.time())}_{hash(str(ask_price) + str(ask_size))}"
                        ask_order = {
                            "id": sim_order_id,
                            "market": market,
                            "side": "sell",
                            "price": ask_price,
                            "amount": ask_size,
                            "filled": 0,
                            "status": "open",
                            "simulated": True
                        }
                        logger.info(f"SIMULATION: Sell order placed: {ask_order}")
                    else:
                        # Real order placement
                        try:
                            ask_order = self.exchange.place_limit_order(market, 'sell', ask_price, ask_size, use_post_only)
                            logger.info(f"Sell order placed: {ask_order}")
                        except Exception as e:
                            if "whitelist" in str(e).lower():
                                logger.error(f"IP whitelist error when placing sell order: {str(e)}. Consider adding this IP to your exchange whitelist or using simulation mode.")
                            else:
                                logger.error(f"Failed to place sell order: {str(e)}")
                else:
                    logger.warning(f"Insufficient balance to place sell order. Required: {min_order_size} {symbol}, Available: {symbol_balance} {symbol}")
                
                # Send position telemetry for monitoring
                self.util.post_positions_to_influx(
                    exchange="gateio",
                    subaccount="main",
                    mid=mid_price,
                    bid_spread=bid_spread,
                    ask_spread=ask_spread,
                    symbol=market,
                    position=position
                )

                # Sleep for the configured interval
                sleep_time = self.config['quote_interval_seconds']
                logger.info(f"Sleeping for {sleep_time} seconds...")
                time.sleep(sleep_time)

            except Exception as e:
                logger.error(f"Error in main loop: {str(e)}")
                traceback.print_exc()
                time.sleep(5)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config_path", help="Path to config file", nargs='?')
    parser.add_argument("--config", help="Path to config file")
    args = parser.parse_args()
    
    # Use either positional argument or --config flag
    config_path = args.config_path if args.config_path else args.config
    
    if not config_path:
        print("Error: No config path provided. Please specify a config file path.")
        sys.exit(1)
        
    # Print for debugging
    print(f"Starting GateIO bot with config path: {config_path}")
    
    try:
        bot = GateioBot(config_path=config_path)
        bot.run()
    except Exception as e:
        print(f"Error initializing bot: {e}")
        traceback.print_exc()
        sys.exit(1)
