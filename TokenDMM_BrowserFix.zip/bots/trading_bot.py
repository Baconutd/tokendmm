# trading_bot.py (replaces dummy_bot.py in production)

import os
import sys
import time
import json
import signal
import logging
import traceback
from pathlib import Path
from typing import Dict
from datetime import datetime

# Add project root to python path to resolve imports
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_root not in sys.path:
    sys.path.append(project_root)

import pandas as pd

from exchange.bitget import BitGetexchange
from helper import Utils

# Setup logging
# Create logs directory if it doesn't exist
logs_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../logs")
os.makedirs(logs_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.join(logs_dir, "bitget_bot.log"), mode='a')
    ]
)

logger = logging.getLogger(__name__)

class TradingBot:
    def __init__(self, config_path: str):
        self.config_path = Path(config_path)
        self.running = True
        self.load_config()
        self.setup_exchange()
        # Initialize Utils with proper exchange name and no credentials file
        self.util = Utils(exchange='bitget')
        self.last_config_mtime = self.config_path.stat().st_mtime

    def load_config(self):
        with open(self.config_path) as f:
            self.config = json.load(f)

    def setup_exchange(self):
        keys = self.config["api_keys"]
        self.exchange = BitGetexchange(
            keys["api_key"],
            keys["secret_key"],
            keys["passphrase"]
        )

    def handle_signal(self, signum, frame):
        print("Shutdown signal received")
        self.running = False

    def run(self):
        signal.signal(signal.SIGINT, self.handle_signal)
        signal.signal(signal.SIGTERM, self.handle_signal)

        symbol = self.config["symbol"]
        base_symbol = self.config["base_symbol"]
        market = f"{symbol}{base_symbol}"

        while self.running:
            try:
                # Reload config if updated
                current_mtime = self.config_path.stat().st_mtime
                if current_mtime != self.last_config_mtime:
                    print("Reloading config...")
                    self.load_config()
                    self.setup_exchange()
                    self.last_config_mtime = current_mtime

                # Cancel open orders on restart
                self.exchange.cancel_all_orders(f"{symbol}_{base_symbol}")

                # Get open orders and balances
                oo, boo, soo = self.exchange.get_open_orders(f"{symbol}-{base_symbol}")
                balances = self.exchange.get_account_balances()

                # Clean balances
                balances.loc['USDT', 'balance'] = max(0, balances.loc['USDT', 'balance'] - self.config["reserve_base_symbol"])
                balances.loc[symbol.upper(), 'balance'] -= self.config["reserve_symbol"]

                # Generate quotes and manage orders
                self.util.post_positions_to_influx(
                    exchange="bitget",
                    subaccount="dmmsubacc",
                    mid=1.0,  # Placeholder
                    bid_spread=0.01,  # Placeholder
                    ask_spread=0.01,  # Placeholder
                    symbol=market.upper(),
                    position=0.5  # Placeholder
                )

                time.sleep(1)  # Simulate quoting loop

            except Exception as e:
                print("Exception occurred:", e)
                traceback.print_exc()
                time.sleep(5)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", help="Path to config file")
    args = parser.parse_args()

    bot = TradingBot(config_path=args.config)
    bot.run()
