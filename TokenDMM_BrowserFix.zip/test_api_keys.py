#!/usr/bin/env python3
"""
Test script to verify the Gate.io API keys and check if the current IP is whitelisted.
"""

import os
import sys
import requests
import time
import hmac
import hashlib
import base64
import json
from urllib.parse import urlencode

def gen_sign(method, url, query_string=None, payload_string=None, api_key=None, api_secret=None):
    """Generate authentication signature for Gate.io API requests"""
    t = time.time()
    m = hashlib.sha512()
    m.update((payload_string or "").encode('utf-8'))
    hashed_payload = m.hexdigest()
    s = '%s\n%s\n%s\n%s\n%s' % (method, url, query_string or "", hashed_payload, t)
    sign = hmac.new(api_secret.encode('utf-8'), s.encode('utf-8'), hashlib.sha512).hexdigest()
    return {'KEY': api_key, 'SIGN': sign, 'Timestamp': str(t)}

def test_gateio_api(api_key, api_secret):
    """Test the Gate.io API keys and check if the current IP is whitelisted."""
    try:
        # First, get the current market price as a public API call (no auth needed)
        base_url = "https://api.gateio.ws"
        endpoint = "/api/v4/spot/tickers"
        params = {"currency_pair": "BTC_USDT"}
        
        url = f"{base_url}{endpoint}?{urlencode(params)}"
        response = requests.get(url)
        
        if response.status_code != 200:
            print(f"❌ Failed to get public market data: {response.status_code}")
            print(response.text)
            return False
        
        print(f"✅ Successfully connected to Gate.io public API")
        ticker_data = response.json()[0]
        print(f"   BTC/USDT Price: {ticker_data['last']}")
        
        # Now test the private API that requires authentication
        endpoint = "/api/v4/spot/accounts"
        params = {}
        
        url = f"{base_url}{endpoint}"
        headers = gen_sign('GET', endpoint, '', '', api_key, api_secret)
        
        print("\nTesting private API (requires IP whitelist)...")
        response = requests.get(url, headers=headers)
        
        if response.status_code != 200:
            print(f"❌ Private API call failed: {response.status_code}")
            print(response.text)
            error_text = response.text.lower()
            
            if "whitelist" in error_text:
                print("\n⚠️  IP WHITELIST ISSUE DETECTED")
                print("Your current IP address is not whitelisted on Gate.io.")
                print("You need to add your current IP to the whitelist in your Gate.io account settings.")
                
                # Try to get the current IP
                try:
                    ip_response = requests.get("https://api.ipify.org")
                    if ip_response.status_code == 200:
                        print(f"\nYour current IP address appears to be: {ip_response.text}")
                        print("Please add this IP to your Gate.io API key whitelist.")
                except Exception as e:
                    print("Could not determine your current IP address.")
            return False
        
        print(f"✅ Successfully authenticated with Gate.io private API")
        print(f"   Your IP is correctly whitelisted!")
        
        # Print balance information
        balances = response.json()
        print("\nAccount Balances:")
        for balance in balances:
            if float(balance['available']) > 0:
                print(f"   {balance['currency']}: {balance['available']} (Available)")
        
        return True
    
    except Exception as e:
        print(f"❌ Error testing Gate.io API: {str(e)}")
        return False

if __name__ == "__main__":
    # Try to get API keys from environment variables
    api_key = os.environ.get('GATEIO_API_KEY')
    api_secret = os.environ.get('GATEIO_SECRET_KEY')
    
    # Check if API keys are provided
    if not api_key or not api_secret:
        print("❌ API keys not found in environment variables.")
        print("Please set GATEIO_API_KEY and GATEIO_SECRET_KEY environment variables.")
        sys.exit(1)
    
    # Test the API keys
    success = test_gateio_api(api_key, api_secret)
    
    # Exit with appropriate code
    sys.exit(0 if success else 1)