# TokenDMM - Trading Bot Manager

A comprehensive web-based platform for cryptocurrency market making bot management, focusing on intelligent bot deployment, real-time performance monitoring, and advanced optimization strategies.

## Key Features

- React.js frontend for dynamic user interface
- Python FastAPI backend with advanced bot management capabilities
- Real-time performance tracking and detailed bot status monitoring
- Secure authentication and deployment mechanisms
- Enhanced bot information display with uptime and status tracking
- Support for Bitget exchange API

## Project Structure

- `frontend/`: React.js frontend application
- `backend/`: FastAPI backend server
- `bots/`: Trading bot implementation files
- `configs/`: Configuration files for trading bots

## Getting Started

### Prerequisites

- Node.js 18+
- Python 3.9+
- Docker (optional, for containerized deployment)

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/Baconutd/tokendmm.git
   cd tokendmm
   ```

2. Install backend dependencies:
   ```
   cd backend
   pip install -r requirements.txt
   ```

3. Install frontend dependencies:
   ```
   cd frontend
   npm install
   ```

### Running the Application

1. Start the backend server:
   ```
   cd backend
   python main.py
   ```

2. Start the frontend development server:
   ```
   cd frontend
   npm run dev
   ```

3. Access the application at http://localhost:5000

## Docker Deployment

You can also run the application using Docker:

```
docker-compose up
```

## Authentication

The application uses HTTP Basic Authentication with the following default credentials:
- Username: admin
- Password: trading123

*Note: Change these credentials for production use.*

## API Endpoints

### Bot Management
- `GET /bots` - List all bots
- `POST /bots` - Deploy a new bot
- `GET /bots/{bot_name}` - Get details for a specific bot
- `GET /bots/{bot_name}/status` - Get concise status for a specific bot
- `PUT /bots/{bot_name}/config` - Update a bot's configuration
- `POST /bots/{bot_name}/stop` - Stop a running bot
- `POST /bots/{bot_name}/start` - Start a stopped bot

## Bot Configuration

A typical bot configuration includes:
```json
{
  "name": "BitgetBTC",
  "exchange": "bitget",
  "trading_pair": "BTC/USDT",
  "symbol": "BTC",
  "base_symbol": "USDT",
  "quote_interval_seconds": 30,
  "spread_percentage": 0.2,
  "max_order_size": 0.01,
  "reserve_symbol": 0.001,
  "reserve_base_symbol": 10.0,
  "strategy": "basic_market_maker",
  "api_keys": {
    "api_key": "your_api_key_here",
    "secret_key": "your_secret_key_here",
    "passphrase": "your_passphrase_here"
  }
}
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.
## Updated via Direct Git Pipeline
This line was added to test the direct git pipeline from Replit to GitHub.
