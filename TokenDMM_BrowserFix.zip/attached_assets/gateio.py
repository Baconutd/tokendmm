import time
import hashlib
import hmac
import requests
import pandas as pd
import json
import gate_api
import logging
import sys

class GateIo:
    def __init__(self,api_key,api_secret) -> None:
        self.base_url="https://api.gateio.ws"
        self.api_key=api_key        # api_key
        self.api_secret = api_secret     # api_secret
        self.session = requests.session()
        gate_conf = gate_api.Configuration(key=api_key, secret=api_secret)
        gate_client = gate_api.ApiClient(gate_conf)
        self.spotapi = gate_api.SpotApi(gate_client)
        walletapi = gate_api.WalletApi(gate_client)
        deliveryapi = gate_api.DeliveryApi(gate_client)
        self.proxy = {"https": "http://39k_dev:p6CxXZ2SqR027nHym@46.101.13.238:3128"}


    def gen_sign(self,method, url, query_string=None, payload_string=None):
        t = time.time()
        m = hashlib.sha512()
        m.update((payload_string or "").encode('utf-8'))
        hashed_payload = m.hexdigest()
        s = '%s\n%s\n%s\n%s\n%s' % (method, url, query_string or "", hashed_payload, t)
        sign = hmac.new(self.api_secret.encode('utf-8'), s.encode('utf-8'), hashlib.sha512).hexdigest()
        return {'KEY': self.api_key, 'Timestamp': str(t), 'SIGN': sign}

    def get_funds(self):
        funds = self.spotapi.list_spot_accounts()
        for i in range(len(funds)):
            funds[i] = funds[i].to_dict()


        funds = pd.DataFrame(funds, columns=['currency', 'available', 'locked'])
        funds.index = funds.currency
        funds.available = pd.to_numeric(funds.available)
        funds.locked = pd.to_numeric(funds.locked)
        funds['amount'] = funds.available + funds.locked
        return funds


    def get_balance(self):
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        balance_list = []
        url = '/wallet/total_balance'
        query_param = ''
        prefix = "/api/v4"

        # Generate signed headers
        sign_headers = self.gen_sign('GET', prefix + url, query_param)
        headers.update(sign_headers)

        # Update session headers
        self.session.headers.update(headers)
        balance_list=[]
        try:
        # Make the request using the session
            response = self.session.get(self.base_url + prefix + url,proxies=self.proxy)
            balance_list.append(response.json()['details']['spot'])
        except Exception as e:
            print(f"An error occurred: {e}")
        return pd.DataFrame(balance_list)
    
    # %%
    def get_orderBook (self,currency_pair, depth):
        s = self.spotapi.list_order_book(currency_pair, limit=depth).to_dict()
        bob = pd.DataFrame(s['bids'], columns=['price', 'qty'], dtype=float)
        sob = pd.DataFrame(s['asks'], columns=['price', 'qty'], dtype=float)
        bob.index = bob.price
        sob.index = sob.price
        return bob, sob


        
    def get_open_orders(self):
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}

        url = '/spot/open_orders'
        query_param = ''
        # for `gen_sign` implementation, refer to section `Authentication` above
        sign_headers = self.gen_sign('GET', prefix + url, query_param)
        headers.update(sign_headers)
        response = requests.request('GET', self.base_url + prefix + url, headers=headers)
        oo,boo,soo = pd.DataFrame(),pd.DataFrame(),pd.DataFrame()
        if response.status_code == 200:

            response_json = response.json()

            if response_json and len(response_json) > 0 and 'orders' in response_json[0]:
                orders = response_json[0]['orders']
                if orders:

                    oo=pd.DataFrame(response.json()[0]['orders'])
                    columns=oo.columns
                    oo, boo, soo = pd.DataFrame(response.json()[0]['orders'],columns=columns),pd.DataFrame(),pd.DataFrame()
                
                    oo['order_id'] = oo['id']

                    oo['price'], oo['amount'], oo['executedQty'] = oo['price'].astype(float), oo['amount'].astype(float),  oo['filled_amount'].astype(float)
                    oo['remaining'] = oo['amount'] - oo['executedQty']
                    oo['volume'] = oo['remaining']
                    
                    oo.index = oo.order_id
                    boo = oo[oo["side"] == "buy"]
                    soo = oo[oo["side"] == "sell"]
                    return oo,boo,soo
            
            else:
                return oo,boo,soo
                    
        
    
    def place_order(self,symbol,order_type,side,price,quantity,postOnly=True,client_order_id=None):
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        url = '/spot/orders'
        query_param = ''
        # Create a dictionary with the initial values
        body_dict = {

            "text": 't-'+str(client_order_id[28:]),
            "time_in_force": "gtc"
        }
        if postOnly:    
            # Update the dictionary with the variables
            body_dict.update({
                "currency_pair": symbol,
                "type": order_type,
                "side": side,
                "amount": float(quantity),
                "price": float(price),
                "time_in_force":"poc"
            })
        else:
            # Update the dictionary with the variables
            body_dict.update({
                "currency_pair": symbol,
                "type": order_type,
                "side": side,
                "amount": float(quantity),
                "price": float(price),
                "time_in_force":"gtc"
            })

        # Convert the dictionary to a JSON-formatted string
        body = json.dumps(body_dict)
        
        sign_headers = self.gen_sign('POST', prefix + url, query_param, body)
        headers.update(sign_headers)
        response = requests.request('POST', self.base_url + prefix + url, headers=headers, data=body)

        return response.json()
    
    def replace_order(self,symbol,side,orderid,qty=None,price=None):
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        url = f'/spot/orders/{orderid}'
        query_param = ''
        random_id = 't-abc123456'
        type='limit'
         # Create the data dictionary
        data = {
            "text": random_id,
            "currency_pair": symbol,
            "type": type,
            "side": side
        }

        # Conditionally add qty and price if they are not None
        if qty is not None:
            data["amount"] = qty
        if price is not None:
            data["price"] = price


        # Convert the dictionary to a JSON-formatted string
        body = json.dumps(data)

        sign_headers = self.gen_sign('PATCH', prefix + url, query_param, body)
        headers.update(sign_headers)
        response = requests.request('PATCH', self.base_url + prefix + url, headers=headers, data=body)
        #print(response.json())
        return response.json()
    
    def cancel_order(self,orderid,symbol):
        host = "https://api.gateio.ws"
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}

        url = f'/spot/orders/{orderid}'
        query_param = f'currency_pair={symbol}'
        # for `gen_sign` implementation, refer to section `Authentication` above
        sign_headers = self.gen_sign('DELETE', prefix + url, query_param)
        headers.update(sign_headers)
        r = requests.request('DELETE', host + prefix + url + "?" + query_param, headers=headers)
        #print(r.json())
        return r

    def get_order_book(self,symbol):
        host = "https://api.gateio.ws"
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}

        url = '/spot/order_book'
        query_param = f'currency_pair={symbol}'
        try:
            r = requests.request('GET', host + prefix + url + "?" + query_param, headers=headers)
        except Exception as e:
            print(f"An error occurred: {e}")

        bid=float(r.json()['bids'][0][0])
        ask=float(r.json()['asks'][0][0])
        return bid,ask,(bid+ask)/2



    def get_funds1(self):
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        url = '/spot/accounts'
        query_param = ''
        # for `gen_sign` implementation, refer to section `Authentication` above
        sign_headers = self.gen_sign('GET',prefix + url,query_param)
        headers.update(sign_headers)
        
        r = requests.request('GET',self.base_url + prefix + url, headers=headers)
        r = r.json()
        balances=pd.DataFrame(r)
        balances['available'] = balances['available'].astype(float)
        balances['locked'] = balances['locked'].astype(float)
        balances['amount']=balances['available']+balances['locked']
        balances.index=balances.currency
        return balances
    
    def cancel_all_orders(self,symbol):
        host = "https://api.gateio.ws"
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}

        url = '/spot/orders'
        #query_param = f'currency_pair={symbol}'
        query_param = ''
        # for `gen_sign` implementation, refer to section `Authentication` above
        sign_headers = self.gen_sign('DELETE', prefix + url, query_param)
        headers.update(sign_headers)
        r = requests.request('DELETE', host + prefix + url, headers=headers)
        print(r.json())

    def create_batch_orders(self, client_order_id,orders):
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
        url = '/spot/batch_orders'
        query_param = ''
        # Ensure 'text' field length is within the allowed limit
        for order in orders:
            if 'text' in order and len(order['text']) > 30:
                order['text'] = order['text'][:30]
    
        orders_json = json.dumps(orders)
        
        orders_string = ', '.join([str(order) for order in orders])
        sign_headers = self.gen_sign('POST', prefix + url, query_param, orders_json)
        headers.update(sign_headers)
        response = requests.request('POST', self.base_url + prefix + url, headers=headers, data=orders_json)

        return response
    
    def replace_batch_orders(self,replace):
        host = "https://api.gateio.ws"
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}

        url = '/spot/amend_batch_orders'
        query_param = ''
        for order in replace:
            if 'text' in order and len(order['text']) > 30:
                order['text'] = order['text'][:30]
    
        orders_json = json.dumps(replace)
       
        # for `gen_sign` implementation, refer to section `Authentication` above
        sign_headers = self.gen_sign('POST', prefix + url, query_param, orders_json)
        headers.update(sign_headers)
        r = requests.request('POST', host + prefix + url, headers=headers, data=orders_json)
        print(r.json())
        return r


    def cancel_batch_orders(self,cancels):
        host = "https://api.gateio.ws"
        prefix = "/api/v4"
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}

        url = '/spot/cancel_batch_orders'
        query_param = ''
        for order in cancels:
            if 'text' in order and len(order['text']) > 30:
                order['text'] = order['text'][:30]
    
        orders_json = json.dumps(cancels)
       
        # for `gen_sign` implementation, refer to section `Authentication` above
        sign_headers = self.gen_sign('POST', prefix + url, query_param, orders_json)
        headers.update(sign_headers)
        r = requests.request('POST', host + prefix + url, headers=headers, data=orders_json)
        print(r.json())
        return r



    


# %%
