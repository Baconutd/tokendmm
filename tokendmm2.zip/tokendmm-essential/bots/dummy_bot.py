#!/usr/bin/env python3
import json
import time
import random
import sys
import os
import signal
import logging
from datetime import datetime
from typing import Dict, Any

# Configure logging
import os
log_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "logs"))
os.makedirs(log_dir, exist_ok=True)

# Set up file and console handlers
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        # Console handler for standard output
        logging.StreamHandler(),
        # File handler for persistent logs
        logging.FileHandler(os.path.join(log_dir, "bot_activity.log"))
    ]
)
logger = logging.getLogger("dummy_bot")

class DummyTradingBot:
    def __init__(self, config_path: str):
        self.config_path = config_path
        self.config = self.load_config()
        self.running = True
        self.orders = []
        self.last_config_modified_time = os.path.getmtime(config_path)
        
        # Set up signal handlers for graceful shutdown
        signal.signal(signal.SIGTERM, self.handle_shutdown)
        signal.signal(signal.SIGINT, self.handle_shutdown)
        
        logger.info(f"Initialized dummy trading bot with config: {self.config}")
    
    def load_config(self) -> Dict[str, Any]:
        """Load bot configuration from file"""
        try:
            with open(self.config_path, 'r') as f:
                config = json.load(f)
                logger.info(f"Loaded configuration: {config}")
                return config
        except Exception as e:
            logger.error(f"Failed to load config: {str(e)}")
            return {}
    
    def check_config_updated(self) -> bool:
        """Check if configuration file has been modified"""
        try:
            current_modified_time = os.path.getmtime(self.config_path)
            if current_modified_time > self.last_config_modified_time:
                self.last_config_modified_time = current_modified_time
                return True
        except Exception as e:
            logger.error(f"Error checking config file: {str(e)}")
        return False
    
    def reload_config(self) -> None:
        """Reload configuration if it's been modified"""
        if self.check_config_updated():
            logger.info("Configuration file updated, reloading...")
            self.cancel_all_orders()
            self.config = self.load_config()
            logger.info(f"Reloaded configuration: {self.config}")
    
    def cancel_all_orders(self) -> None:
        """Cancel all active orders (simulated)"""
        # Extract bot ID from the config path (file name without extension)
        bot_id = os.path.basename(self.config_path).replace('.json', '')
        
        # Always log this message, even if there are no orders (requested feature)
        logger.info(f"[{bot_id}] Cancelling all open orders before applying new config...")
        
        if self.orders:
            logger.info(f"Cancelling {len(self.orders)} active orders on {self.config.get('exchange', 'unknown')}")
            logger.info(f"Trading pair: {self.config.get('trading_pair', 'unknown')}")
            
            # Simulate API cancellation process
            for order in self.orders:
                order_id = order.get('id', 'unknown')
                order_type = order.get('type', 'unknown')
                order_price = order.get('price', 0)
                order_size = order.get('size', 0)
                
                logger.info(f"Cancelling {order_type} order {order_id} at price {order_price} with size {order_size}")
                
                # Simulate API latency
                time.sleep(0.1)
                
                # Log confirmation of cancellation
                logger.info(f"Order {order_id} cancelled successfully")
                
            # Clear order list after all cancellations
            previous_orders_count = len(self.orders)
            self.orders = []
            logger.info(f"[{bot_id}] Order cancellation complete: {previous_orders_count} orders removed from book")
        else:
            logger.info(f"[{bot_id}] No active orders to cancel")
    
    def place_orders(self) -> None:
        """Simulate placing bid and ask orders"""
        if not self.config:
            logger.warning("No configuration available, skipping order placement")
            return
        
        # Extract parameters from config
        trading_pair = self.config.get('trading_pair', 'BTC/USDT')
        spread = self.config.get('spread_percentage', 0.2) / 100
        max_order_size = self.config.get('max_order_size', 0.01)
        
        # Simulate market price
        current_price = 30000 + random.uniform(-1000, 1000)
        
        # Calculate bid and ask prices
        bid_price = current_price * (1 - spread/2)
        ask_price = current_price * (1 + spread/2)
        
        # Random order sizes
        bid_size = round(random.uniform(0.001, max_order_size), 6)
        ask_size = round(random.uniform(0.001, max_order_size), 6)
        
        # Cancel previous orders first
        self.cancel_all_orders()
        
        # Place new orders
        bid_order = {
            'id': f"bid_{int(time.time())}_{random.randint(1000, 9999)}",
            'type': 'bid',
            'pair': trading_pair,
            'price': round(bid_price, 2),
            'size': bid_size,
            'time': datetime.now().isoformat()
        }
        
        ask_order = {
            'id': f"ask_{int(time.time())}_{random.randint(1000, 9999)}",
            'type': 'ask',
            'pair': trading_pair,
            'price': round(ask_price, 2),
            'size': ask_size,
            'time': datetime.now().isoformat()
        }
        
        self.orders = [bid_order, ask_order]
        logger.info(f"Placed bid order: {bid_order}")
        logger.info(f"Placed ask order: {ask_order}")
        
        # Simulate occasional fills
        if random.random() < 0.1:
            filled_order = random.choice(self.orders)
            self.orders.remove(filled_order)
            logger.info(f"Order filled: {filled_order}")
            
            # Immediately replace filled order
            new_order = filled_order.copy()
            new_order['id'] = f"{filled_order['type']}_{int(time.time())}_{random.randint(1000, 9999)}"
            new_order['time'] = datetime.now().isoformat()
            self.orders.append(new_order)
            logger.info(f"Placed replacement order: {new_order}")
    
    def report_status(self) -> None:
        """Report current bot status and metrics"""
        name = self.config.get('name', 'unnamed_bot')
        exchange = self.config.get('exchange', 'unknown')
        trading_pair = self.config.get('trading_pair', 'unknown')
        
        # Simulate some metrics
        position = random.uniform(-0.1, 0.1)
        pnl = random.uniform(-100, 100)
        
        logger.info(f"Bot status: {name} on {exchange}")
        logger.info(f"Trading pair: {trading_pair}")
        logger.info(f"Current position: {position:.6f}")
        logger.info(f"Unrealized PnL: ${pnl:.2f}")
        logger.info(f"Active orders: {len(self.orders)}")
        logger.info("---" * 10)
    
    def handle_shutdown(self, signum, frame) -> None:
        """Handle shutdown signals gracefully"""
        logger.info(f"Received signal {signum}, shutting down gracefully")
        self.running = False
        self.cancel_all_orders()
    
    def run(self) -> None:
        """Main bot loop"""
        logger.info(f"Starting dummy trading bot: {self.config.get('name', 'unnamed')}")
        
        try:
            while self.running:
                # Check for config updates
                self.reload_config()
                
                # Get quote interval from config (with default fallback)
                quote_interval = self.config.get('quote_interval_seconds', 30)
                
                # Place orders
                self.place_orders()
                
                # Report status
                self.report_status()
                
                # Sleep until next cycle
                for _ in range(quote_interval):
                    if not self.running:
                        break
                    time.sleep(1)
        
        except Exception as e:
            logger.error(f"Bot error: {str(e)}")
        finally:
            logger.info("Bot shutting down...")
            self.cancel_all_orders()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        logger.error("Usage: python dummy_bot.py <config_path>")
        sys.exit(1)
    
    config_path = sys.argv[1]
    
    # Check if config file exists
    if not os.path.isfile(config_path):
        logger.error(f"Config file not found: {config_path}")
        sys.exit(1)
    
    # Start the bot
    bot = DummyTradingBot(config_path)
    bot.run()
