# Bot Configurations Directory

This directory contains configuration files for all trading bots.

## File Format

Configurations are stored as JSON files with the following naming convention:
