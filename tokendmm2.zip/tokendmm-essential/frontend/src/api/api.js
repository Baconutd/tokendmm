import axios from 'axios';

// Auth credentials for development - in production these would be securely obtained
const username = "admin";
const password = "trading123";

// Create authorization header
const authHeader = 'Basic ' + btoa(`${username}:${password}`);

// Create axios instance with base URL and auth
const api = axios.create({
  baseURL: '/api',  // This will be proxied to the backend by Vite
  headers: {
    'Content-Type': 'application/json',
    'Authorization': authHeader
  },
  timeout: 30000, // 30 second timeout
});

// Fetch all bots
export const fetchBots = async () => {
  try {
    const response = await api.get('/bots');
    return response.data;
  } catch (error) {
    console.error('Error fetching bots:', error);
    throw new Error(error.response?.data?.detail || 'Failed to fetch bots');
  }
};

// Deploy a new bot
export const deployBot = async (botConfig) => {
  try {
    const response = await api.post('/bots', botConfig);
    return response.data;
  } catch (error) {
    console.error('Error deploying bot:', error);
    throw new Error(error.response?.data?.detail || 'Failed to deploy bot');
  }
};

// Get details for a specific bot
export const getBotDetails = async (botName) => {
  try {
    const response = await api.get(`/bots/${botName}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching bot details for ${botName}:`, error);
    throw new Error(error.response?.data?.detail || 'Failed to fetch bot details');
  }
};

// Get real-time status information for a specific bot
export const getBotStatus = async (botName) => {
  try {
    // Create a specific instance with a longer timeout just for status requests
    const statusApi = axios.create({
      baseURL: '/api',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader
      },
      timeout: 30000 // 30 second timeout specifically for status requests
    });
    
    const response = await statusApi.get(`/bots/${botName}/status`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching bot status for ${botName}:`, error);
    throw new Error(error.response?.data?.detail || 'Failed to fetch bot status');
  }
};

// Update a bot's configuration
export const updateBotConfig = async (botName, configUpdate) => {
  try {
    const response = await api.put(`/bots/${botName}/config`, {
      config: configUpdate
    });
    return response.data;
  } catch (error) {
    console.error(`Error updating config for bot ${botName}:`, error);
    throw new Error(error.response?.data?.detail || 'Failed to update bot configuration');
  }
};

// Stop a running bot
export const stopBot = async (botName) => {
  try {
    const response = await api.delete(`/bots/${botName}`);
    return response.data;
  } catch (error) {
    console.error(`Error stopping bot ${botName}:`, error);
    throw new Error(error.response?.data?.detail || 'Failed to stop bot');
  }
};

// Start a stopped bot
export const startBot = async (botName) => {
  try {
    const response = await api.post(`/bots/${botName}/start`);
    return response.data;
  } catch (error) {
    console.error(`Error starting bot ${botName}:`, error);
    throw new Error(error.response?.data?.detail || 'Failed to start bot');
  }
};

export default api;
