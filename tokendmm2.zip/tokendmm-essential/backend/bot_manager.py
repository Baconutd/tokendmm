import subprocess
import logging
import os
import time
import signal
import json
from datetime import datetime
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class BotManager:
    def __init__(self):
        self.bots = {}  # Dict to track running bots: {name: {process, start_time, status}}
    
    def bot_exists(self, bot_name: str) -> bool:
        """Check if a bot with the given name exists and is running or error state"""
        return bot_name in self.bots
    
    def start_bot(self, bot_name: str, config_path: str) -> None:
        """Start a bot process with the specified configuration"""
        logger.info(f"Starting bot: {bot_name} with config: {config_path}")
        
        # Check if bot is already running
        if self.bot_exists(bot_name):
            if self.bots[bot_name]["process"] and self.bots[bot_name]["process"].poll() is None:
                logger.warning(f"Bot {bot_name} is already running. Stopping it first.")
                self.stop_bot(bot_name)
        
        try:
            # Start the real trading bot as a subprocess
            # Use absolute path for all file paths to avoid path issues
            absolute_config_path = os.path.abspath(config_path)
            bot_script_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "bots", "trading_bot.py"))
            
            process = subprocess.Popen(
                ["python", bot_script_path, "--config", absolute_config_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                preexec_fn=os.setsid  # Allows killing the entire process group
            )
            
            # Track the bot in our dictionary
            self.bots[bot_name] = {
                "process": process,
                "start_time": time.time(),
                "status": "running",
                "pid": process.pid,
                "config_path": config_path
            }
            
            logger.info(f"Bot {bot_name} started with PID {process.pid}")
            
            # Monitor bot process for errors (this is a non-blocking check)
            self._check_bot_status(bot_name)
            
        except Exception as e:
            logger.error(f"Error starting bot {bot_name}: {str(e)}")
            self.bots[bot_name] = {
                "process": None,
                "start_time": time.time(),
                "status": "error",
                "error": str(e),
                "config_path": config_path
            }
    
    def stop_bot(self, bot_name: str) -> None:
        """Stop a running bot"""
        if not self.bot_exists(bot_name):
            logger.warning(f"Bot {bot_name} not found, cannot stop.")
            return
        
        bot_info = self.bots[bot_name]
        process = bot_info.get("process")
        
        if process and process.poll() is None:
            logger.info(f"Stopping bot {bot_name} with PID {process.pid}")
            try:
                # Send SIGTERM to the process group
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                
                # Wait a bit for graceful shutdown
                time.sleep(1)
                
                # Force kill if still running
                if process.poll() is None:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                    logger.warning(f"Force killed bot {bot_name}")
            except Exception as e:
                logger.error(f"Error stopping bot {bot_name}: {str(e)}")
        
        # Update status
        self.bots[bot_name]["status"] = "stopped"
        self.bots[bot_name]["stop_time"] = time.time()
    
    def get_all_bots(self) -> List[Dict]:
        """Get information about all bots"""
        result = []
        
        for name, info in self.bots.items():
            # Check for any status changes
            self._check_bot_status(name)
            
            # Calculate uptime
            uptime = 0
            if info["status"] == "running":
                uptime = time.time() - info["start_time"]
            elif "stop_time" in info:
                uptime = info["stop_time"] - info["start_time"]
            
            # Get config file information similar to get_bot_status endpoint
            config_path = info.get("config_path", None)
            config_hash = "unknown"
            config_timestamp = 0
            last_updated = None
            
            if config_path and os.path.exists(config_path):
                try:
                    # Get the config modification time as timestamp
                    config_timestamp = os.path.getmtime(config_path)
                    last_updated = datetime.fromtimestamp(config_timestamp).isoformat()
                    
                    # Calculate a simple hash of the config file content
                    with open(config_path, "rb") as f:
                        import hashlib
                        config_content = f.read()
                        config_hash = hashlib.md5(config_content).hexdigest()
                except Exception as e:
                    logger.warning(f"Error getting config file info for {name}: {str(e)}")
            
            bot_data = {
                "name": name,
                "status": info["status"],
                "uptime": round(uptime),
                "uptime_formatted": self._format_uptime(uptime),
                "pid": info.get("pid", None),
                "config_path": config_path,
                "config_hash": config_hash,
                "config_timestamp": config_timestamp,
                "last_updated": last_updated
            }
            
            # Add error info if present
            if "error" in info:
                bot_data["error"] = info["error"]
            
            result.append(bot_data)
        
        return result
    
    def get_bot_info(self, bot_name: str) -> Dict:
        """Get detailed information about a specific bot"""
        if not self.bot_exists(bot_name):
            return {"error": "Bot not found"}
        
        # Check for any status changes
        self._check_bot_status(bot_name)
        
        info = self.bots[bot_name]
        
        # Calculate uptime
        uptime = 0
        if info["status"] == "running":
            uptime = time.time() - info["start_time"]
        elif "stop_time" in info:
            uptime = info["stop_time"] - info["start_time"]
        
        # Try to get recent logs
        process = info.get("process")
        logs = []
        if process and hasattr(process, "stderr") and process.stderr:
            try:
                # Non-blocking read from stderr
                err_lines = process.stderr.readlines(100)  # Get last 100 lines max
                logs = [line.strip() for line in err_lines]
            except Exception as e:
                logs = [f"Error reading logs: {str(e)}"]
        
        return {
            "name": bot_name,
            "status": info["status"],
            "uptime": round(uptime),
            "uptime_formatted": self._format_uptime(uptime),
            "pid": info.get("pid", None),
            "config_path": info.get("config_path", None),
            "logs": logs
        }
    
    def _check_bot_status(self, bot_name: str) -> None:
        """Check if a bot process is still running and update status"""
        if not self.bot_exists(bot_name):
            return
        
        bot_info = self.bots[bot_name]
        process = bot_info.get("process")
        
        if process:
            # Check process status
            exit_code = process.poll()
            
            # If exit_code is not None, the process has terminated
            if exit_code is not None and bot_info["status"] == "running":
                logger.warning(f"Bot {bot_name} terminated with exit code {exit_code}")
                
                # Update status based on exit code
                if exit_code == 0:
                    bot_info["status"] = "completed"
                else:
                    bot_info["status"] = "error"
                    try:
                        stderr_output = process.stderr.read() if process.stderr else ""
                        bot_info["error"] = stderr_output or f"Exited with code {exit_code}"
                    except Exception:
                        bot_info["error"] = f"Exited with code {exit_code}"
                
                bot_info["stop_time"] = time.time()
    
    def get_bot_status(self, bot_name: str) -> Dict:
        """Get standardized status information for a specific bot"""
        if not self.bot_exists(bot_name):
            return {"error": "Bot not found"}
        
        # Check for any status changes
        self._check_bot_status(bot_name)
        
        info = self.bots[bot_name]
        
        # Calculate uptime
        uptime = 0
        if info["status"] == "running":
            uptime = time.time() - info["start_time"]
        elif "stop_time" in info:
            uptime = info["stop_time"] - info["start_time"]
        
        # Get config file information
        config_path = info.get("config_path", None)
        last_config_update = None
        
        if config_path and os.path.exists(config_path):
            try:
                # Get the config modification time as timestamp
                config_timestamp = os.path.getmtime(config_path)
                last_config_update = datetime.fromtimestamp(config_timestamp).isoformat()
            except Exception as e:
                logger.warning(f"Error getting config file info for {bot_name}: {str(e)}")
        
        return {
            "id": bot_name,
            "name": bot_name,
            "status": info["status"],
            "pid": info.get("pid", None),
            "uptime_seconds": round(uptime),
            "last_config_update": last_config_update
        }

    def _format_uptime(self, seconds: float) -> str:
        """Format seconds into a human-readable uptime string"""
        seconds = int(seconds)
        
        days, seconds = divmod(seconds, 86400)
        hours, seconds = divmod(seconds, 3600)
        minutes, seconds = divmod(seconds, 60)
        
        parts = []
        if days > 0:
            parts.append(f"{days}d")
        if hours > 0 or days > 0:
            parts.append(f"{hours}h")
        if minutes > 0 or hours > 0 or days > 0:
            parts.append(f"{minutes}m")
        parts.append(f"{seconds}s")
        
        return " ".join(parts)
