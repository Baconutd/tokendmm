from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field, ValidationError, validator
import secrets
import os
import json
import logging
from typing import List, Dict, Optional
import time
from datetime import datetime
from bot_manager import BotManager

app = FastAPI(title="Trading Bot Manager API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["WWW-Authenticate"]
)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize bot manager
bot_manager = BotManager()

# Ensure configs directory exists (use parent directory for consistent bot access)
configs_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "configs"))
os.makedirs(configs_dir, exist_ok=True)

# Setup authentication
security = HTTPBasic()

# In production, load these from environment variables
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "trading123"

def verify_credentials(credentials: HTTPBasicCredentials = Depends(security)):
    correct_username = secrets.compare_digest(credentials.username, ADMIN_USERNAME)
    correct_password = secrets.compare_digest(credentials.password, ADMIN_PASSWORD)
    
    if not (correct_username and correct_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
    
    return credentials.username

# Models
class ApiKeys(BaseModel):
    api_key: str = Field(..., description="API key for exchange")
    secret_key: str = Field(..., description="Secret key for exchange")
    passphrase: str = Field(..., description="Passphrase for exchange (if required)")

class BotConfig(BaseModel):
    name: str = Field(..., description="Unique name for the bot")
    exchange: str = Field(..., description="Exchange where the bot will trade")
    trading_pair: str = Field(..., description="Trading pair in format like BTC/USDT")
    symbol: str = Field(..., description="Base currency symbol (e.g. BTC)")
    base_symbol: str = Field(..., description="Quote currency symbol (e.g. USDT)")
    quote_interval_seconds: int = Field(
        ..., 
        gt=0, 
        le=3600, 
        description="Interval between quote updates in seconds"
    )
    spread_percentage: float = Field(
        ..., 
        gt=0, 
        le=10, 
        description="Spread percentage for market making"
    )
    max_order_size: float = Field(
        ..., 
        gt=0, 
        description="Maximum order size in base currency"
    )
    reserve_symbol: float = Field(
        0.0, 
        ge=0.0, 
        description="Amount of base currency to reserve (not use for trading)"
    )
    reserve_base_symbol: float = Field(
        0.0, 
        ge=0.0, 
        description="Amount of quote currency to reserve (not use for trading)"
    )
    strategy: str = Field(
        "basic_market_maker", 
        description="Trading strategy to use"
    )
    api_keys: ApiKeys = Field(
        ..., 
        description="API keys for the exchange"
    )
    additional_params: Optional[Dict] = Field(
        {}, 
        description="Additional strategy-specific parameters"
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "name": "BitgetBTC",
                "exchange": "bitget",
                "trading_pair": "BTC/USDT",
                "symbol": "BTC",
                "base_symbol": "USDT",
                "quote_interval_seconds": 30,
                "spread_percentage": 0.2,
                "max_order_size": 0.01,
                "reserve_symbol": 0.001,
                "reserve_base_symbol": 10.0,
                "strategy": "basic_market_maker",
                "api_keys": {
                    "api_key": "your_api_key_here",
                    "secret_key": "your_secret_key_here",
                    "passphrase": "your_passphrase_here"
                }
            }
        }

class BotEditConfig(BaseModel):
    config: Dict = Field(
        ..., 
        description="Updated configuration for the bot"
    )
    
    # Validator to ensure the config contains required fields
    @validator('config')
    def validate_bot_config(cls, v):
        required_fields = [
            'exchange', 'trading_pair', 'symbol', 'base_symbol',
            'quote_interval_seconds', 'spread_percentage', 'max_order_size',
            'reserve_symbol', 'reserve_base_symbol', 'api_keys'
        ]
        missing_fields = [field for field in required_fields if field not in v]
        
        if missing_fields:
            raise ValueError(f"Missing required fields in config: {', '.join(missing_fields)}")
        
        # Check if api_keys has all required fields
        if 'api_keys' in v:
            api_keys = v['api_keys']
            required_key_fields = ['api_key', 'secret_key', 'passphrase']
            missing_key_fields = [field for field in required_key_fields if field not in api_keys]
            if missing_key_fields:
                raise ValueError(f"Missing required fields in api_keys: {', '.join(missing_key_fields)}")
            
        # Validate field types and constraints
        if 'quote_interval_seconds' in v and (
            not isinstance(v['quote_interval_seconds'], int) or 
            v['quote_interval_seconds'] <= 0 or 
            v['quote_interval_seconds'] > 3600
        ):
            raise ValueError("quote_interval_seconds must be an integer between 1 and 3600")
            
        if 'spread_percentage' in v and (
            not isinstance(v['spread_percentage'], (int, float)) or 
            v['spread_percentage'] <= 0 or 
            v['spread_percentage'] > 10
        ):
            raise ValueError("spread_percentage must be a number between 0 and 10")
            
        if 'max_order_size' in v and (
            not isinstance(v['max_order_size'], (int, float)) or 
            v['max_order_size'] <= 0
        ):
            raise ValueError("max_order_size must be a positive number")
        
        if 'reserve_symbol' in v and (
            not isinstance(v['reserve_symbol'], (int, float)) or 
            v['reserve_symbol'] < 0
        ):
            raise ValueError("reserve_symbol must be a non-negative number")
            
        if 'reserve_base_symbol' in v and (
            not isinstance(v['reserve_base_symbol'], (int, float)) or 
            v['reserve_base_symbol'] < 0
        ):
            raise ValueError("reserve_base_symbol must be a non-negative number")
            
        return v

# Routes
@app.get("/")
async def root():
    return {"message": "Trading Bot Manager API"}

@app.get("/bots")
async def list_bots(username: str = Depends(verify_credentials)):
    """Get a list of all running bots with their status"""
    bots = bot_manager.get_all_bots()
    return {"bots": bots}

@app.post("/bots", status_code=201)
async def deploy_bot(bot_config: BotConfig, background_tasks: BackgroundTasks, username: str = Depends(verify_credentials)):
    """Deploy a new trading bot with the given configuration"""
    try:
        # Validate bot name
        if not bot_config.name or bot_config.name.strip() == "":
            raise HTTPException(status_code=400, detail="Bot name cannot be empty")
        
        # Check if bot already exists
        if bot_manager.bot_exists(bot_config.name):
            raise HTTPException(status_code=400, detail=f"Bot with name '{bot_config.name}' already exists")
        
        # Config validation is automatically handled by Pydantic
        # Any validation errors will be returned as 422 Unprocessable Entity
        
        # Save config to file
        config_path = os.path.join(configs_dir, f"{bot_config.name}.json")
        with open(config_path, "w") as f:
            # Use model_dump() instead of dict() for Pydantic v2 compatibility
            json.dump(bot_config.model_dump(), f, indent=4)
        
        logger.info(f"Saved config for bot '{bot_config.name}' to {config_path}")
        
        # Launch bot in background
        background_tasks.add_task(
            bot_manager.start_bot,
            bot_config.name,
            config_path
        )
        
        return {"message": f"Bot '{bot_config.name}' deployment initiated", "status": "deploying"}
    except ValidationError as e:
        # Extract validation error messages
        error_details = []
        for error in e.errors():
            field = error.get('loc', ['unknown'])[0]
            msg = error.get('msg', 'Unknown error')
            error_details.append(f"{field}: {msg}")
        
        # Return validation errors with 422 status code
        raise HTTPException(
            status_code=422, 
            detail=f"Configuration validation failed: {'; '.join(error_details)}"
        )
    except HTTPException as he:
        # Re-raise HTTP exceptions as they already have proper status codes
        raise he
    except Exception as e:
        # Handle any other unexpected errors
        logger.error(f"Error deploying bot: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to deploy bot: {str(e)}")

@app.get("/bots/{bot_name}")
async def get_bot(bot_name: str, username: str = Depends(verify_credentials)):
    """Get details for a specific bot"""
    if not bot_manager.bot_exists(bot_name):
        raise HTTPException(status_code=404, detail=f"Bot '{bot_name}' not found")
    
    bot_info = bot_manager.get_bot_info(bot_name)
    
    # Read current config
    config_path = os.path.join(configs_dir, f"{bot_name}.json")
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
    except FileNotFoundError:
        config = {"error": "Config file not found"}
    
    # Also get the standardized status
    status = bot_manager.get_bot_status(bot_name)
    
    return {
        "bot": bot_info,
        "config": config,
        "status": status
    }

@app.get("/bots/{bot_name}/status")
async def get_bot_status(bot_name: str, username: str = Depends(verify_credentials)):
    """Get concise status information for a specific bot"""
    if not bot_manager.bot_exists(bot_name):
        raise HTTPException(status_code=404, detail=f"Bot '{bot_name}' not found")
    
    # Get standardized bot status from the bot manager
    status = bot_manager.get_bot_status(bot_name)
    
    # If there's an error, it means the bot wasn't found
    if "error" in status:
        raise HTTPException(status_code=404, detail=f"Bot '{bot_name}' not found")
    
    return status

@app.put("/bots/{bot_name}/config")
async def update_bot_config(bot_name: str, config_update: BotEditConfig, background_tasks: BackgroundTasks, username: str = Depends(verify_credentials)):
    """Update a bot's configuration and restart it"""
    if not bot_manager.bot_exists(bot_name):
        raise HTTPException(status_code=404, detail=f"Bot '{bot_name}' not found")
    
    # Read current config first to ensure it exists
    config_path = os.path.join(configs_dir, f"{bot_name}.json")
    try:
        with open(config_path, "r") as f:
            current_config = json.load(f)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"Config file for bot '{bot_name}' not found")
    
    # Validate the config using the BotConfig model (for parameters not validated in BotEditConfig)
    try:
        # Try to create a new BotConfig from the updated config
        # This will use our updated config, but keep the original name
        updated_config = config_update.model_dump()["config"]
        updated_config['name'] = bot_name  # Ensure name remains unchanged
        
        # Try to validate against full BotConfig schema
        try:
            # Create a temporary bot config object for validation (won't be used directly)
            BotConfig(**updated_config)
        except ValidationError as e:
            # Extract validation error messages
            error_details = []
            for error in e.errors():
                field = error.get('loc', ['unknown'])[0]
                msg = error.get('msg', 'Unknown error')
                error_details.append(f"{field}: {msg}")
            
            # Return validation errors with 422 status code
            raise HTTPException(
                status_code=422, 
                detail=f"Configuration validation failed: {'; '.join(error_details)}"
            )
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        logger.error(f"Error validating config: {str(e)}")
        raise HTTPException(status_code=422, detail=f"Invalid configuration: {str(e)}")
    
    # If validation passed, update config file
    with open(config_path, "w") as f:
        json.dump(updated_config, f, indent=4)
    
    logger.info(f"Updated config for bot '{bot_name}'")
    
    # Stop the bot first (which cancels orders)
    bot_manager.stop_bot(bot_name)
    
    # Start the bot with new config in background
    background_tasks.add_task(
        bot_manager.start_bot,
        bot_name,
        config_path
    )
    
    return {"message": f"Bot '{bot_name}' restarting with new configuration", "status": "restarting"}

@app.delete("/bots/{bot_name}")
async def stop_bot(bot_name: str, username: str = Depends(verify_credentials)):
    """Stop a running bot"""
    if not bot_manager.bot_exists(bot_name):
        raise HTTPException(status_code=404, detail=f"Bot '{bot_name}' not found")
    
    bot_manager.stop_bot(bot_name)
    
    return {"message": f"Bot '{bot_name}' stopped successfully"}

@app.post("/bots/{bot_name}/start", status_code=200)
async def start_bot(bot_name: str, background_tasks: BackgroundTasks, username: str = Depends(verify_credentials)):
    """Start a stopped bot using its existing configuration"""
    # Check if bot exists first (even if stopped)
    if not bot_manager.bot_exists(bot_name):
        raise HTTPException(status_code=404, detail=f"Bot '{bot_name}' not found")
    
    # Get bot info to check status
    bot_info = bot_manager.get_bot_info(bot_name)
    
    # Only start if bot is stopped
    if bot_info["status"] == "running":
        return {"message": f"Bot '{bot_name}' is already running", "status": "running"}
    
    # Get the config path for this bot
    config_path = os.path.join(configs_dir, f"{bot_name}.json")
    
    if not os.path.exists(config_path):
        raise HTTPException(status_code=404, detail=f"Config file for bot '{bot_name}' not found")
    
    # Start the bot with existing config in background
    background_tasks.add_task(
        bot_manager.start_bot,
        bot_name,
        config_path
    )
    
    return {"message": f"Bot '{bot_name}' starting", "status": "starting"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
