import React, { useState, useEffect } from 'react';
import { getBotDetails, updateBotConfig } from '../api/api';

function EditBotConfig({ botName, onClose, onSuccess }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [configText, setConfigText] = useState('');
  const [originalConfig, setOriginalConfig] = useState(null);
  const [saveLoading, setSaveLoading] = useState(false);
  const [parseError, setParseError] = useState(null);

  useEffect(() => {
    const fetchBotDetails = async () => {
      try {
        setLoading(true);
        const response = await getBotDetails(botName);
        const config = response.config;
        
        setOriginalConfig(config);
        setConfigText(JSON.stringify(config, null, 2));
        setError(null);
      } catch (err) {
        setError(`Failed to load bot details: ${err.message}`);
        console.error('Error loading bot details:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchBotDetails();
  }, [botName]);

  const handleConfigChange = (e) => {
    setConfigText(e.target.value);
    try {
      JSON.parse(e.target.value);
      setParseError(null);
    } catch (err) {
      setParseError(`Invalid JSON: ${err.message}`);
    }
  };

  const handleSave = async () => {
    try {
      // Final validation
      const configObj = JSON.parse(configText);
      
      setSaveLoading(true);
      await updateBotConfig(botName, configObj);
      onSuccess();
      onClose();
    } catch (err) {
      setError(`Failed to update config: ${err.message}`);
      console.error('Error updating config:', err);
    } finally {
      setSaveLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Edit Configuration: {botName}</h3>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p>{error}</p>
          </div>
        )}

        {parseError && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4" role="alert">
            <p>{parseError}</p>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center items-center p-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bot Configuration (JSON)
              </label>
              <textarea
                value={configText}
                onChange={handleConfigChange}
                rows="20"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 font-mono text-sm"
              ></textarea>
              <p className="mt-1 text-sm text-gray-500">
                Edit the JSON configuration. The bot will restart with new settings.
              </p>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={saveLoading || parseError !== null}
                className={`px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md ${(saveLoading || parseError !== null) ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {saveLoading ? (
                  <span className="inline-flex items-center">
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Saving...
                  </span>
                ) : 'Save & Restart Bot'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default EditBotConfig;
