import React from 'react';
import { stopBot, startBot } from '../api/api';

function BotList({ bots, loading, onEdit, onBotAction }) {
  const [actionLoading, setActionLoading] = React.useState(null);
  const [actionType, setActionType] = React.useState(null); // 'start' or 'stop'
  const [error, setError] = React.useState(null);

  const handleStopBot = async (botName) => {
    try {
      setActionLoading(botName);
      setActionType('stop');
      await stopBot(botName);
      setError(null);
      
      // Notify parent component to refresh data
      if (onBotAction) {
        onBotAction('stop', botName);
      }
    } catch (err) {
      setError(`Failed to stop bot: ${err.message}`);
      console.error('Error stopping bot:', err);
    } finally {
      setActionLoading(null);
      setActionType(null);
    }
  };
  
  const handleStartBot = async (botName) => {
    try {
      setActionLoading(botName);
      setActionType('start');
      await startBot(botName);
      setError(null);
      
      // Notify parent component to refresh data
      if (onBotAction) {
        onBotAction('start', botName);
      }
    } catch (err) {
      setError(`Failed to start bot: ${err.message}`);
      console.error('Error starting bot:', err);
    } finally {
      setActionLoading(null);
      setActionType(null);
    }
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'running':
        return 'bg-green-100 text-green-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      case 'stopped':
        return 'bg-gray-100 text-gray-800';
      case 'deploying':
      case 'restarting':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  if (loading && (!bots || bots.length === 0)) {
    return (
      <div className="flex justify-center items-center p-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!loading && (!bots || bots.length === 0)) {
    return (
      <div className="bg-white rounded-lg shadow p-6 text-center">
        <p className="text-lg text-gray-600">No bots are currently deployed.</p>
        <p className="text-gray-500 mt-2">Deploy a new bot to get started.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto bg-white rounded-lg shadow">
      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
          <p>{error}</p>
        </div>
      )}
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Bot Name
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Uptime
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              PID
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Last Config Update
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {bots.map((bot) => (
            <tr key={bot.id || `bot-${bot.name}`} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="font-medium text-gray-900">{bot.name}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(bot.status)}`}>
                  {bot.status}
                </span>
                {bot.error && (
                  <div className="text-xs text-red-500 mt-1">
                    {typeof bot.error === 'string' && bot.error.length > 50 
                      ? bot.error.substring(0, 50) + '...' 
                      : bot.error}
                  </div>
                )}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {bot.uptime_formatted || '-'}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {bot.pid || '-'}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {bot.last_config_update 
                  ? new Date(bot.last_config_update).toLocaleString() 
                  : '-'}
                {bot.config_hash && (
                  <div className="text-xs text-gray-400 mt-1 truncate max-w-xs" title={bot.config_hash}>
                    Hash: {bot.config_hash.substring(0, 8)}...
                  </div>
                )}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button
                  onClick={() => onEdit(bot)}
                  className="text-indigo-600 hover:text-indigo-900 mr-4"
                >
                  Edit Config
                </button>

                {/* Show Stop Button for running bots */}
                {bot.status === 'running' && (
                  <button
                    onClick={() => handleStopBot(bot.name)}
                    disabled={actionLoading === bot.name}
                    className={`text-red-600 hover:text-red-900 ${actionLoading === bot.name ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    {actionLoading === bot.name && actionType === 'stop' ? (
                      <span className="inline-flex items-center">
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Stopping...
                      </span>
                    ) : 'Stop Bot'}
                  </button>
                )}

                {/* Show Start Button for stopped bots */}
                {bot.status === 'stopped' && (
                  <button
                    onClick={() => handleStartBot(bot.name)}
                    disabled={actionLoading === bot.name}
                    className={`text-green-600 hover:text-green-900 ${actionLoading === bot.name ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    {actionLoading === bot.name && actionType === 'start' ? (
                      <span className="inline-flex items-center">
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-green-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Starting...
                      </span>
                    ) : 'Start Bot'}
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {loading && (
        <div className="flex justify-center items-center p-4 border-t border-gray-200">
          <div className="text-sm text-gray-500">Refreshing...</div>
        </div>
      )}
    </div>
  );
}

export default BotList;
