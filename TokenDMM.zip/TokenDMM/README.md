# Trading Bot Manager

A web-based internal tool that allows traders to deploy and manage crypto market making bots.

## Features

- Deploy new trading bots with customizable configurations
- List and monitor all running bots
- Edit bot configurations on the fly
- Start/stop bots as needed
- View bot status and uptime

## Project Structure

